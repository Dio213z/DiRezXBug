// ═══════════════════════════════════════════════════════════════
// APP CONFIG — SATU TEMPAT UNTUK DOMAIN & PORT
// Ganti di sini saja, semua file langsung update otomatis
// ═══════════════════════════════════════════════════════════════

const String kDomain = 'nitz.pterodactyl.panelkuy.my.id';
const int    kPort   = 2265;

/// Base URL siap pakai — gunakan ini di seluruh app
const String kBaseUrl = 'http://$kDomain:$kPort';

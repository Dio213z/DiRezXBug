import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'app_config.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final TextEditingController targetController = TextEditingController();
  late final AnimationController _pulseController;
  late final AnimationController _glowController;
  late final Animation<double> _pulseAnimation;
  
  String selectedBugId = "";
  bool isSending = false;
  String? responseMessage;
  
  late VideoPlayerController _videoController;
  ChewieController? _chewieController;
  bool isVideoInitialized = false;

  String _targetMode = "number";
  String _senderType = "private";
  List<dynamic> _globalSenders = [];
  bool _isLoadingGlobalSenders = false;
  String? _globalSenderError;
  String _selectedSenderId = "";

  int _currentBugIndex = 0;
  late PageController _bugPageController;

  static const Color _bgDark = Color(0xFF0A0E27);
  static const Color _cardDark = Color(0xFF1A1F3F);
  static const Color _accentRed = Color(0xFFF44336);
  static const Color _darkRed = Color(0xFFB71C1C);
  static const Color _softRed = Color(0xFFEF5350);
  static const Color _textWhite = Color(0xFFFFFFFF);
  static const Color _textGrey = Color(0xFF94A3B8);
  static const Color _successGreen = Color(0xFF10B981);
  static const Color _errorRed = Color(0xFFEF4444);
  static const Color _warningOrange = Color(0xFFF59E0B);

  LinearGradient get _primaryGradient => const LinearGradient(
    colors: [Color(0xFFF44336), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(_pulseController);
    
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _bugPageController = PageController();
    _initializeVideoPlayer();
    _loadGlobalSenders();
  }

  Future<void> _loadGlobalSenders() async {
    setState(() {
      _isLoadingGlobalSenders = true;
      _globalSenderError = null;
    });

    try {
      final response = await http.get(
        Uri.parse("$kBaseUrl/globalSender?key=${widget.sessionKey}"),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() {
            _globalSenders = data["connections"] ?? [];
            if (_globalSenders.isNotEmpty) {
              _selectedSenderId = _globalSenders[0]['id'].toString();
            }
            _isLoadingGlobalSenders = false;
          });
        } else {
          setState(() {
            _globalSenderError = data["message"] ?? "Failed to load global senders";
            _isLoadingGlobalSenders = false;
          });
        }
      } else {
        setState(() {
          _globalSenderError = "Server error: ${response.statusCode}";
          _isLoadingGlobalSenders = false;
        });
      }
    } catch (e) {
      setState(() {
        _globalSenderError = "Connection failed: $e";
        _isLoadingGlobalSenders = false;
      });
    }
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4');
    _videoController.initialize().then((_) {
      if (mounted) {
        setState(() {
          _videoController.setVolume(0);
          _chewieController = ChewieController(
            videoPlayerController: _videoController,
            autoPlay: true,
            looping: true,
            showControls: false,
            autoInitialize: true,
          );
          isVideoInitialized = true;
        });
      }
    }).catchError((error) {
      debugPrint("Video error: $error");
      if (mounted) {
        setState(() {
          isVideoInitialized = false;
        });
      }
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _glowController.dispose();
    targetController.dispose();
    _bugPageController.dispose();
    _videoController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  String? _formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool _isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_targetMode == "number") {
      final target = _formatPhoneNumber(rawInput);
      if (target == null) {
        _showMessageDialog("Invalid Number", "Use international format (e.g., +62, +1, +44)");
        return;
      }
    } else {
      if (!_isValidGroupLink(rawInput)) {
        _showMessageDialog("Invalid Link", "Please enter a valid WhatsApp group link");
        return;
      }
    }

    setState(() {
      isSending = true;
      responseMessage = null;
    });

    try {
      String apiUrl;
      if (_senderType == "private") {
        apiUrl = "$kBaseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId";
      } else {
        if (_selectedSenderId.isEmpty && _globalSenders.isNotEmpty) {
          _selectedSenderId = _globalSenders[0]['id'].toString();
        }
        apiUrl = "$kBaseUrl/sendGlobalBug?key=$key&target=$rawInput&bug=$selectedBugId&senderId=$_selectedSenderId";
      }
      
      final res = await http.get(Uri.parse(apiUrl)).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body);

      if (!mounted) return;

      if (data["cooldown"] == true) {
        setState(() => responseMessage = "⏳ Cooldown: Please wait a moment");
      } else if (data["valid"] == false) {
        setState(() => responseMessage = "❌ Invalid Session: Please login again");
      } else if (data["sended"] == false) {
        setState(() => responseMessage = "⚠️ Failed: Server under maintenance");
      } else {
        setState(() => responseMessage = "✅ Attack sent successfully!");
        targetController.clear();
      }
    } catch (e) {
      if (mounted) {
        setState(() => responseMessage = "❌ Error: Connection failed");
      }
    } finally {
      if (mounted) {
        setState(() => isSending = false);
      }
    }
  }

  void _showMessageDialog(String title, String msg) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: _cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: _primaryGradient,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning_rounded, color: _textWhite, size: 32),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  color: _textWhite,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                msg,
                textAlign: TextAlign.center,
                style: const TextStyle(color: _textGrey, fontSize: 14),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _accentRed,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text("OK", style: TextStyle(color: _textWhite, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Row(
        children: [
          Expanded(
            child: _buildModeButton(
              isSelected: _targetMode == "number",
              label: "BUG NOMOR",
              icon: Icons.phone_android,
              onTap: () => setState(() => _targetMode = "number"),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: _buildModeButton(
              isSelected: _targetMode == "group",
              label: "BUG GROUP",
              icon: Icons.group,
              onTap: () => setState(() => _targetMode = "group"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeButton({
    required bool isSelected,
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: isSelected ? _primaryGradient : null,
          color: isSelected ? null : _cardDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? _accentRed : _accentRed.withOpacity(0.25),
            width: isSelected ? 1.5 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: _accentRed.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: isSelected ? _textWhite : _accentRed, size: 20),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? _textWhite : _accentRed,
                fontWeight: FontWeight.w700,
                fontSize: 14,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTargetInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 6),
          child: Text(
            "NOMOR TARGET",
            style: TextStyle(color: _textGrey, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: _cardDark,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: _accentRed.withOpacity(0.25)),
          ),
          child: TextField(
            controller: targetController,
            style: const TextStyle(color: _textWhite, fontSize: 14),
            cursorColor: _accentRed,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(
              hintText: "628xxxxxxxxxx",
              hintStyle: TextStyle(color: _textGrey.withOpacity(0.5), fontSize: 13),
              border: InputBorder.none,
              prefixIcon: Icon(Icons.phone_android, color: _accentRed, size: 22),
              contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBugSlider() {
    if (widget.listBug.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(32),
        decoration: BoxDecoration(
          color: _cardDark,
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Center(
          child: Text("No bugs available", style: TextStyle(color: _textGrey, fontSize: 13)),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 4, bottom: 12),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 14,
                decoration: BoxDecoration(
                  color: _accentRed,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(width: 8),
              const Text(
                "PILIH BUG",
                style: TextStyle(
                  color: _textWhite,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 120,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: widget.listBug.length,
            itemBuilder: (context, index) {
              final bug = widget.listBug[index];
              final isSelected = selectedBugId == bug['bug_id'];

              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedBugId = bug['bug_id'];
                    _currentBugIndex = index;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  width: 150,
                  margin: EdgeInsets.only(
                    left: index == 0 ? 0 : 10,
                    right: index == widget.listBug.length - 1 ? 0 : 0,
                  ),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isSelected ? _accentRed : _cardDark,
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: isSelected ? _accentRed : Colors.white10,
                      width: 1,
                    ),
                  ),
                  child: Stack(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(
                            Icons.security,
                            color: isSelected ? Colors.white : _accentRed,
                            size: 20,
                          ),
                          const Spacer(),
                          Text(
                            bug['bug_name']?.toUpperCase() ?? 'UNKNOWN',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            "ID: ${bug['bug_id']}",
                            style: TextStyle(
                              color: isSelected ? Colors.white70 : _textGrey,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                      if (isSelected)
                        Positioned(
                          top: 0,
                          right: 0,
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Colors.green,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(
                              Icons.check,
                              color: Colors.white,
                              size: 14,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildSenderTypeSelector() {
    return Container(
      margin: const EdgeInsets.only(top: 16, bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 8),
            child: Text(
              "PILIH SENDER",
              style: TextStyle(color: _textGrey, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: _buildSenderButton(
                  title: "PRIVATE",
                  isSelected: _senderType == "private",
                  onTap: () => setState(() => _senderType = "private"),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: _buildSenderButton(
                  title: "GLOBAL",
                  isSelected: _senderType == "global",
                  onTap: () => setState(() => _senderType = "global"),
                  count: _globalSenders.length,
                  isLoading: _isLoadingGlobalSenders,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSenderButton({
    required String title,
    required bool isSelected,
    required VoidCallback onTap,
    int? count,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: isSelected ? _primaryGradient : null,
          color: isSelected ? null : _cardDark,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? _accentRed : _accentRed.withOpacity(0.25),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              title == "PRIVATE" ? Icons.phone_android : Icons.public,
              color: isSelected ? _textWhite : _accentRed,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                color: isSelected ? _textWhite : _accentRed,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
            if (count != null && !isLoading && count > 0) ...[
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: isSelected ? _textWhite.withOpacity(0.2) : _accentRed.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  "$count",
                  style: TextStyle(
                    color: isSelected ? _textWhite : _accentRed,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
            if (isLoading)
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2, color: _accentRed),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, child) {
        return Container(
          width: double.infinity,
          height: 54,
          margin: const EdgeInsets.only(top: 16),
          decoration: BoxDecoration(
            gradient: _primaryGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: _accentRed.withOpacity(0.4),
                blurRadius: 16,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ElevatedButton(
            onPressed: isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            ),
            child: isSending
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(color: _textWhite, strokeWidth: 2.5),
                  )
                : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.send_rounded, color: _textWhite, size: 20),
                      SizedBox(width: 10),
                      Text(
                        "KIRIM",
                        style: TextStyle(color: _textWhite, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Widget _buildResponseMessage() {
    if (responseMessage == null) return const SizedBox.shrink();

    Color msgColor;
    if (responseMessage!.contains("✅")) {
      msgColor = _successGreen;
    } else if (responseMessage!.contains("❌")) {
      msgColor = _errorRed;
    } else {
      msgColor = _warningOrange;
    }

    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: msgColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: msgColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(
            responseMessage!.contains("✅") ? Icons.check_circle : Icons.error,
            color: msgColor,
            size: 18,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              responseMessage!,
              style: TextStyle(color: msgColor, fontSize: 12, fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgDark,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_cardDark, _cardDark.withOpacity(0.8)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _accentRed.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        gradient: _primaryGradient,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: _accentRed.withOpacity(0.4), blurRadius: 20),
                        ],
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/reze.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Icon(
                            Icons.person,
                            color: _textWhite,
                            size: 36,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.username,
                            style: const TextStyle(
                              color: _textWhite,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _accentRed.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  widget.role,
                                  style: TextStyle(color: _accentRed, fontSize: 10, fontWeight: FontWeight.w600),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _darkRed.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  "Exp: ${widget.expiredDate}",
                                  style: const TextStyle(color: _textGrey, fontSize: 10),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (isVideoInitialized && _chewieController != null)
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _accentRed.withOpacity(0.3), width: 1.5),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: AspectRatio(
                      aspectRatio: _videoController.value.aspectRatio,
                      child: Chewie(controller: _chewieController!),
                    ),
                  ),
                ),
              const SizedBox(height: 20),
              _buildModeSelector(),
              _buildTargetInput(),
              const SizedBox(height: 16),
              _buildBugSlider(),
              _buildSenderTypeSelector(),
              _buildSendButton(),
              _buildResponseMessage(),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
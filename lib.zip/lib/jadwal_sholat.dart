import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class JadwalSholatPage extends StatefulWidget {
  const JadwalSholatPage({super.key});

  @override
  State<JadwalSholatPage> createState() => _JadwalSholatPageState();
}

class _JadwalSholatPageState extends State<JadwalSholatPage> {
  DateTime selectedDate = DateTime.now();
  
  // Jadwal sholat FIXED (contoh jam untuk wilayah Indonesia)
  final Map<String, String> jadwalSholat = {
    "Subuh": "04:30",
    "Dzuhur": "12:00",
    "Ashar": "15:30",
    "Maghrib": "18:00",
    "Isya": "19:30",
  };
  
  // Warna tema
  static const Color bgDark = Color(0xFF0B0B0E);
  static const Color accentBlue = Color(0xFF2196F3);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFFA0A0A0);
  static const Color successGreen = Color(0xFF4CAF50);

  String getCurrentTime() {
    return DateFormat('HH : mm : ss').format(DateTime.now());
  }
  
  String getCurrentTimeStatus() {
    final hour = DateTime.now().hour;
    if (hour >= 3 && hour < 11) return "Pagi";
    if (hour >= 11 && hour < 15) return "Siang";
    if (hour >= 15 && hour < 18) return "Sore";
    return "Malam";
  }
  
  String getNextPrayer() {
    final now = DateTime.now();
    final currentHour = now.hour;
    final currentMinute = now.minute;
    final currentTime = currentHour * 60 + currentMinute;
    
    final List<Map<String, dynamic>> prayers = [
      {"name": "Subuh", "time": _parseTime(jadwalSholat["Subuh"]!)},
      {"name": "Dzuhur", "time": _parseTime(jadwalSholat["Dzuhur"]!)},
      {"name": "Ashar", "time": _parseTime(jadwalSholat["Ashar"]!)},
      {"name": "Maghrib", "time": _parseTime(jadwalSholat["Maghrib"]!)},
      {"name": "Isya", "time": _parseTime(jadwalSholat["Isya"]!)},
    ];
    
    for (var prayer in prayers) {
      if (prayer["time"] > currentTime) {
        return prayer["name"];
      }
    }
    return "Subuh";
  }
  
  String getNextPrayerTime() {
    final now = DateTime.now();
    final currentHour = now.hour;
    final currentMinute = now.minute;
    final currentTime = currentHour * 60 + currentMinute;
    
    final List<Map<String, dynamic>> prayers = [
      {"name": "Subuh", "time": _parseTime(jadwalSholat["Subuh"]!)},
      {"name": "Dzuhur", "time": _parseTime(jadwalSholat["Dzuhur"]!)},
      {"name": "Ashar", "time": _parseTime(jadwalSholat["Ashar"]!)},
      {"name": "Maghrib", "time": _parseTime(jadwalSholat["Maghrib"]!)},
      {"name": "Isya", "time": _parseTime(jadwalSholat["Isya"]!)},
    ];
    
    for (var prayer in prayers) {
      if (prayer["time"] > currentTime) {
        return prayer["name"] == "Subuh" 
            ? jadwalSholat["Subuh"]! 
            : jadwalSholat[prayer["name"]]!;
      }
    }
    return jadwalSholat["Subuh"]!;
  }
  
  int _parseTime(String time) {
    final parts = time.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);
    return hour * 60 + minute;
  }
  
  String getFormattedDate() {
    return DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(selectedDate);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text(
          "Jadwal Sholat",
          style: TextStyle(
            color: primaryWhite,
            fontWeight: FontWeight.w700,
            fontSize: 18,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: accentBlue, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Tanggal
              Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: accentBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: accentBlue.withOpacity(0.3)),
                  ),
                  child: Text(
                    getFormattedDate(),
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 30),
              
              // Jam sekarang
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [accentBlue.withOpacity(0.15), Colors.transparent],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: accentBlue.withOpacity(0.2)),
                ),
                child: Column(
                  children: [
                    StreamBuilder(
                      stream: Stream.periodic(const Duration(seconds: 1)),
                      builder: (context, snapshot) {
                        return Text(
                          getCurrentTime(),
                          style: const TextStyle(
                            color: primaryWhite,
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: successGreen.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        "Waktu ${getCurrentTimeStatus()}",
                        style: TextStyle(
                          color: successGreen,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 30),
              
              // Jadwal Sholat
              const Text(
                "JADWAL SHOLAT",
                style: TextStyle(
                  color: softGrey,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1.5,
                ),
              ),
              
              const SizedBox(height: 15),
              
              // List 5 Waktu Sholat
              _buildPrayerItem("Subuh", jadwalSholat["Subuh"]!, Icons.wb_twilight, Colors.green),
              _buildPrayerItem("Dzuhur", jadwalSholat["Dzuhur"]!, Icons.wb_sunny, Colors.orange),
              _buildPrayerItem("Ashar", jadwalSholat["Ashar"]!, Icons.sunny, Colors.deepOrange),
              _buildPrayerItem("Maghrib", jadwalSholat["Maghrib"]!, Icons.nights_stay, Colors.purple),
              _buildPrayerItem("Isya", jadwalSholat["Isya"]!, Icons.nightlight_round, Colors.indigo),
              
              const SizedBox(height: 30),
              
              // Waktu Sholat Berikutnya
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [accentBlue, accentBlue.withOpacity(0.7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: accentBlue.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 5),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Text(
                      "WAKTU SHOLAT BERIKUTNYA",
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      getNextPrayer(),
                      style: const TextStyle(
                        color: primaryWhite,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      getNextPrayerTime(),
                      style: const TextStyle(
                        color: primaryWhite,
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 30),
              
              // Hadits
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.green.withOpacity(0.2)),
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.menu_book_rounded, color: Colors.green, size: 28),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Keutamaan Sholat",
                            style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w700),
                          ),
                          SizedBox(height: 5),
                          Text(
                            "Sholat adalah tiang agama, barang siapa mendirikannya maka tegaklah agamanya.",
                            style: TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildPrayerItem(String name, String time, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Text(
            name,
            style: const TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.w600,
              fontSize: 16,
            ),
          ),
          const Spacer(),
          Text(
            time,
            style: TextStyle(
              color: accentBlue,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ],
      ),
    );
  }
}
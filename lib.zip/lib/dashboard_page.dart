import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';

import 'app_config.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'anime.dart';
import 'thanks_to.dart';
import 'spotify_music.dart';
import 'room_public.dart';
import 'device_dashboard.dart';
import 'device_permission.dart';
import 'control_panel.dart';

// Constants for colors - RED THEME
const Color accentRedGlobal = Color(0xFFF44336);
const Color darkRedGlobal = Color(0xFFB71C1C);
const Color softRedGlobal = Color(0xFFEF5350);
const Color primaryWhiteGlobal = Color(0xFFFFFFFF);

// ============ JADWAL SHOLAT PAGE V3 - REAL API ============
class JadwalSholatPage extends StatefulWidget {
  const JadwalSholatPage({super.key});

  @override
  State<JadwalSholatPage> createState() => _JadwalSholatPageState();
}

class _JadwalSholatPageState extends State<JadwalSholatPage> {
  final TextEditingController _cityController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _sholatData;
  String? _errorMessage;
  String _currentTime = '';
  Timer? _timeTimer;

  static const Color bgDark = Color(0xFF0A0E27);
  static const Color accentRed = Color(0xFFF44336);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  static const Color successGreen = Color(0xFF22C55E);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);

  LinearGradient get redGradient => const LinearGradient(
    colors: [Color(0xFFF44336), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  void initState() {
    super.initState();
    _startTimeUpdate();
    _cityController.text = "Jakarta";
    _fetchJadwalSholat();
  }

  @override
  void dispose() {
    _timeTimer?.cancel();
    _cityController.dispose();
    super.dispose();
  }

  void _startTimeUpdate() {
    _updateTime();
    _timeTimer = Timer.periodic(const Duration(seconds: 1), (_) => _updateTime());
  }

  void _updateTime() {
    if (mounted) {
      setState(() {
        _currentTime = DateFormat('HH : mm : ss').format(DateTime.now());
      });
    }
  }

  String _getCurrentTimeStatus() {
    final hour = DateTime.now().hour;
    if (hour >= 3 && hour < 11) return "🌅 Pagi";
    if (hour >= 11 && hour < 15) return "☀️ Siang";
    if (hour >= 15 && hour < 18) return "🌤️ Sore";
    return "🌙 Malam";
  }

  String _getFormattedHijri() {
    final now = DateTime.now();
    final year = now.year;
    final month = now.month;
    final day = now.day;
    final hijriYear = year - 622;
    return "$day/$month/$hijriYear H";
  }

  Future<void> _fetchJadwalSholat() async {
    final city = _cityController.text.trim();
    if (city.isEmpty) {
      setState(() { _errorMessage = "Masukkan nama kota"; });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _sholatData = null;
    });

    try {
      final url = Uri.parse("https://api.aladhan.com/v1/timingsByCity?city=$city&country=Indonesia&method=2");
      final response = await http.get(url).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['code'] == 200) {
          final timings = data['data']['timings'] as Map<String, dynamic>;
          final date = data['data']['date']['readable'];
          final hijri = data['data']['date']['hijri']['date'];
          
          setState(() {
            _sholatData = {
              'lokasi': city.toUpperCase(),
              'tanggal': date,
              'hijri': hijri,
              'waktu': {
                'Imsak': timings['Imsak']?.toString() ?? '--:--',
                'Fajr': timings['Fajr']?.toString() ?? '--:--',
                'Sunrise': timings['Sunrise']?.toString() ?? '--:--',
                'Dhuhr': timings['Dhuhr']?.toString() ?? '--:--',
                'Asr': timings['Asr']?.toString() ?? '--:--',
                'Sunset': timings['Sunset']?.toString() ?? '--:--',
                'Maghrib': timings['Maghrib']?.toString() ?? '--:--',
                'Isha': timings['Isha']?.toString() ?? '--:--',
                'Midnight': timings['Midnight']?.toString() ?? '--:--',
              }
            };
          });
        } else {
          _loadStaticData(city);
        }
      } else {
        _loadStaticData(city);
      }
    } catch (e) {
      _loadStaticData(city);
    } finally {
      setState(() { _isLoading = false; });
    }
  }

  void _loadStaticData(String city) {
    final now = DateTime.now();
    setState(() {
      _sholatData = {
        'lokasi': city.toUpperCase(),
        'tanggal': DateFormat('dd MMMM yyyy', 'id_ID').format(now),
        'hijri': _getFormattedHijri(),
        'waktu': {
          'Imsak': '04:30', 'Fajr': '04:40', 'Sunrise': '05:55',
          'Dhuhr': '12:00', 'Asr': '15:15', 'Sunset': '18:05',
          'Maghrib': '18:05', 'Isha': '19:20', 'Midnight': '00:00',
        }
      };
    });
  }

  IconData _getSholatIcon(String name) {
    switch (name) {
      case 'Imsak': return Icons.bedtime;
      case 'Fajr': return Icons.brightness_5;
      case 'Sunrise': return Icons.wb_sunny;
      case 'Dhuhr': return Icons.sunny;
      case 'Asr': return Icons.brightness_6;
      case 'Maghrib': return Icons.nightlight_round;
      case 'Isha': return Icons.nights_stay;
      default: return Icons.access_time;
    }
  }

  String _formatSholatName(String name) {
    switch (name) {
      case 'Fajr': return 'Subuh';
      case 'Sunrise': return 'Terbit';
      case 'Dhuhr': return 'Dzuhur';
      case 'Asr': return 'Ashar';
      case 'Maghrib': return 'Maghrib';
      case 'Isha': return 'Isya';
      case 'Imsak': return 'Imsak';
      default: return name;
    }
  }

  String? _getNextPrayerTime() {
    if (_sholatData == null) return null;
    final now = DateTime.now();
    final currentMinutes = now.hour * 60 + now.minute;
    final waktu = _sholatData!['waktu'] as Map<String, dynamic>;
    final List<Map<String, dynamic>> prayers = [
      {'name': 'Subuh', 'time': _parseTime(waktu['Fajr']?.toString() ?? '05:00')},
      {'name': 'Dzuhur', 'time': _parseTime(waktu['Dhuhr']?.toString() ?? '12:00')},
      {'name': 'Ashar', 'time': _parseTime(waktu['Asr']?.toString() ?? '15:00')},
      {'name': 'Maghrib', 'time': _parseTime(waktu['Maghrib']?.toString() ?? '18:00')},
      {'name': 'Isya', 'time': _parseTime(waktu['Isha']?.toString() ?? '19:00')},
    ];
    for (var prayer in prayers) {
      if (prayer['time'] > currentMinutes) return prayer['name'];
    }
    return 'Subuh';
  }

  String? _getNextPrayerTimeString() {
    if (_sholatData == null) return null;
    final now = DateTime.now();
    final currentMinutes = now.hour * 60 + now.minute;
    final waktu = _sholatData!['waktu'] as Map<String, dynamic>;
    final List<Map<String, dynamic>> prayers = [
      {'name': 'Fajr', 'time': _parseTime(waktu['Fajr']?.toString() ?? '05:00')},
      {'name': 'Dhuhr', 'time': _parseTime(waktu['Dhuhr']?.toString() ?? '12:00')},
      {'name': 'Asr', 'time': _parseTime(waktu['Asr']?.toString() ?? '15:00')},
      {'name': 'Maghrib', 'time': _parseTime(waktu['Maghrib']?.toString() ?? '18:00')},
      {'name': 'Isha', 'time': _parseTime(waktu['Isha']?.toString() ?? '19:00')},
    ];
    for (var prayer in prayers) {
      if (prayer['time'] > currentMinutes) return waktu[prayer['name']]?.toString() ?? '--:--';
    }
    return waktu['Fajr']?.toString() ?? '05:00';
  }

  int _parseTime(String time) {
    try {
      final parts = time.split(':');
      return int.parse(parts[0]) * 60 + int.parse(parts[1]);
    } catch (e) { return 0; }
  }

  List<Widget> _buildSholatList() {
    final waktu = _sholatData!['waktu'] as Map<String, dynamic>;
    final List<String> order = ['Imsak', 'Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Sunset', 'Maghrib', 'Isha', 'Midnight'];
    final List<Widget> widgets = [];
    for (String key in order) {
      if (waktu.containsKey(key)) {
        widgets.add(_buildSholatCard(name: _formatSholatName(key), time: waktu[key].toString()));
      }
    }
    return widgets;
  }

  Widget _buildSholatCard({required String name, required String time}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: glassPrimary, 
        borderRadius: BorderRadius.circular(16), 
        border: Border.all(color: primaryWhite.withOpacity(0.08))
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8), 
            decoration: BoxDecoration(
              gradient: redGradient, 
              borderRadius: BorderRadius.circular(12)
            ), 
            child: Icon(_getSholatIcon(name), color: primaryWhite, size: 18)
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              name, 
              style: const TextStyle(color: primaryWhite, fontSize: 13, fontWeight: FontWeight.w600)
            )
          ),
          Text(
            time, 
            style: const TextStyle(color: accentRed, fontSize: 14, fontWeight: FontWeight.bold)
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text("Jadwal Sholat", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18)),
        backgroundColor: accentRed,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [accentRed.withOpacity(0.15), bgDark, bgDark],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: primaryWhite.withOpacity(0.1)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _cityController,
                          style: const TextStyle(color: primaryWhite),
                          decoration: InputDecoration(
                            hintText: "Cari kota...",
                            hintStyle: TextStyle(color: softGrey.withOpacity(0.5)),
                            prefixIcon: const Icon(Icons.search, color: accentRed),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                          ),
                          onSubmitted: (_) => _fetchJadwalSholat(),
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(right: 8),
                        decoration: BoxDecoration(
                          gradient: redGradient, 
                          borderRadius: BorderRadius.circular(16)
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
                          onPressed: _fetchJadwalSholat,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                if (_isLoading) const Center(child: CircularProgressIndicator(color: accentRed)),
                if (_errorMessage != null)
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.1), 
                      borderRadius: BorderRadius.circular(16), 
                      border: Border.all(color: Colors.red.withOpacity(0.3))
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.error_outline, color: Colors.red), 
                        const SizedBox(width: 12), 
                        Expanded(child: Text(_errorMessage!, style: const TextStyle(color: Colors.white70)))
                      ]
                    ),
                  ),
                if (_sholatData != null) ...[
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [accentRed.withOpacity(0.15), darkRed.withOpacity(0.1)], 
                        begin: Alignment.topLeft, 
                        end: Alignment.bottomRight
                      ),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
                    ),
                    child: Column(
                      children: [
                        Text(
                          _currentTime, 
                          style: const TextStyle(color: primaryWhite, fontSize: 36, fontWeight: FontWeight.bold, letterSpacing: 2)
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: successGreen.withOpacity(0.15), 
                            borderRadius: BorderRadius.circular(20)
                          ),
                          child: Text(
                            _getCurrentTimeStatus(), 
                            style: TextStyle(color: successGreen, fontSize: 12, fontWeight: FontWeight.w600)
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: glassPrimary, 
                      borderRadius: BorderRadius.circular(24), 
                      border: Border.all(color: primaryWhite.withOpacity(0.08))
                    ),
                    child: Column(
                      children: [
                        const Icon(Icons.mosque, color: accentRed, size: 40),
                        const SizedBox(height: 12),
                        Text(
                          _sholatData!['lokasi'] ?? "Tidak diketahui", 
                          style: const TextStyle(color: primaryWhite, fontSize: 20, fontWeight: FontWeight.bold), 
                          textAlign: TextAlign.center
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: glassSecondary, 
                            borderRadius: BorderRadius.circular(20)
                          ),
                          child: Text(
                            _sholatData!['tanggal'] ?? "", 
                            style: TextStyle(color: softGrey, fontSize: 12)
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _sholatData!['hijri'] ?? "", 
                          style: TextStyle(color: successGreen, fontSize: 12)
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "WAKTU SHOLAT", 
                    style: TextStyle(color: softGrey, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)
                  ),
                  const SizedBox(height: 12),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 2.8,
                    children: _buildSholatList(),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      gradient: redGradient, 
                      borderRadius: BorderRadius.circular(24), 
                      boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 5))]
                    ),
                    child: Column(
                      children: [
                        const Text(
                          "SHOLAT BERIKUTNYA", 
                          style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1)
                        ),
                        const SizedBox(height: 12),
                        Text(
                          _getNextPrayerTime() ?? "--", 
                          style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)
                        ),
                        const SizedBox(height: 8),
                        Text(
                          _getNextPrayerTimeString() ?? "--:--", 
                          style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: successGreen.withOpacity(0.05), 
                      borderRadius: BorderRadius.circular(20), 
                      border: Border.all(color: successGreen.withOpacity(0.2))
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12), 
                          decoration: BoxDecoration(
                            color: successGreen.withOpacity(0.15), 
                            shape: BoxShape.circle
                          ), 
                          child: const Icon(Icons.menu_book_rounded, color: successGreen, size: 28)
                        ),
                        const SizedBox(width: 16),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Keutamaan Sholat", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                              SizedBox(height: 5),
                              Text("Sholat adalah tiang agama, barang siapa mendirikannya maka tegaklah agamanya.", style: TextStyle(color: Colors.white70, fontSize: 12)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ============ HADIS PAGE - FIXED ============
class HadisPage extends StatefulWidget {
  const HadisPage({super.key});

  @override
  State<HadisPage> createState() => _HadisPageState();
}

class _HadisPageState extends State<HadisPage> {
  List<Map<String, dynamic>> _hadiths = [];
  bool _isLoading = true;
  String? _errorMessage;

  static const Color bgDark = Color(0xFF0A0E27);
  static const Color accentRed = Color(0xFFF44336);

  @override
  void initState() {
    super.initState();
    _fetchHadiths();
  }

  Future<void> _fetchHadiths() async {
    setState(() { _isLoading = true; _errorMessage = null; });
    try {
      final response = await http.get(Uri.parse("https://api.hadith.sutanlab.id/books/1?range=1-10")).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data']['hadiths'] != null) {
          final List<dynamic> hadithsData = data['data']['hadiths'];
          setState(() {
            _hadiths = hadithsData.map((h) {
              return {
                'number': h['number']?.toString() ?? '-',
                'arab': h['arab'] ?? '',
                'indonesia': h['indonesia'] ?? '',
              };
            }).toList();
          });
        } else {
          _loadStaticHadiths();
        }
      } else {
        _loadStaticHadiths();
      }
    } catch (e) {
      _loadStaticHadiths();
    } finally {
      setState(() { _isLoading = false; });
    }
  }

  void _loadStaticHadiths() {
    _hadiths = [
      {'number': '1', 'arab': 'إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ', 'indonesia': 'Sesungguhnya setiap amalan tergantung pada niatnya.'},
      {'number': '2', 'arab': 'مَنْ صَامَ رَمَضَانَ إِيمَانًا وَاحْتِسَابًا', 'indonesia': 'Barangsiapa berpuasa Ramadhan karena iman dan mengharap pahala...'},
      {'number': '3', 'arab': 'الدِّينُ النَّصِيحَةُ', 'indonesia': 'Agama itu adalah nasihat.'},
      {'number': '4', 'arab': 'لَا يَشْكُرُ اللَّهَ مَنْ لَا يَشْكُرُ النَّاسَ', 'indonesia': 'Barangsiapa tidak berterima kasih kepada manusia, dia tidak bersyukur kepada Allah.'},
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: AppBar(
        title: const Text("Kumpulan Hadis", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        backgroundColor: accentRed,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white), 
          onPressed: () => Navigator.pop(context)
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: accentRed))
          : _errorMessage != null
              ? Center(child: Text(_errorMessage!, style: const TextStyle(color: Colors.white70)))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _hadiths.length,
                  itemBuilder: (context, index) {
                    final hadith = _hadiths[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A1F3F),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: accentRed.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Hadis No. ${hadith['number']}", style: const TextStyle(color: accentRed, fontWeight: FontWeight.bold, fontSize: 14)),
                          const SizedBox(height: 12),
                          Text(hadith['arab'].toString(), style: const TextStyle(color: Colors.white, fontSize: 16, fontFamily: 'serif'), textAlign: TextAlign.right),
                          const SizedBox(height: 12),
                          const Divider(color: Colors.white24),
                          const SizedBox(height: 8),
                          Text(hadith['indonesia'].toString(), style: const TextStyle(color: Colors.white70, fontSize: 14)),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}

// ============ EXTRA TOOLS PAGES ============
class LanguagePage extends StatelessWidget {
  const LanguagePage({super.key});
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> languages = [
      {"lang": "Indonesia", "hello": "Halo, Selamat pagi"},
      {"lang": "English", "hello": "Hello, Good morning"},
      {"lang": "Jepang", "hello": "Konnichiwa, Ohayou gozaimasu"},
      {"lang": "Korea", "hello": "Annyeonghaseyo, Joheun achim"},
      {"lang": "Mandarin", "hello": "Nǐ hǎo, Zǎo shang hǎo"},
      {"lang": "Perancis", "hello": "Bonjour, Bon matin"},
      {"lang": "Jerman", "hello": "Hallo, Guten Morgen"},
      {"lang": "Spanyol", "hello": "Hola, Buenos días"},
      {"lang": "Italia", "hello": "Ciao, Buongiorno"},
      {"lang": "Rusia", "hello": "Zdravstvuyte, Dobroye utro"},
      {"lang": "Arab", "hello": "Marhaban, Sabah al khayr"},
      {"lang": "Turki", "hello": "Merhaba, Günaydın"},
      {"lang": "Hindi", "hello": "Namaste, Suprabhat"},
      {"lang": "Portugis", "hello": "Olá, Bom dia"},
      {"lang": "Belanda", "hello": "Hallo, Goedemorgen"},
      {"lang": "Swedia", "hello": "Hej, God morgon"},
      {"lang": "Polandia", "hello": "Cześć, Dzień dobry"},
      {"lang": "Yunani", "hello": "Geia sou, Kaliméra"},
      {"lang": "Ceko", "hello": "Ahoj, Dobré ráno"},
      {"lang": "Vietnam", "hello": "Xin chào, Chào buổi sáng"},
      {"lang": "Thailand", "hello": "Sawasdee, Arunsawas"},
      {"lang": "Melayu", "hello": "Hai, Selamat pagi"},
      {"lang": "Tagalog", "hello": "Kumusta, Magandang umaga"},
      {"lang": "Norwegia", "hello": "Hei, God morgen"},
      {"lang": "Finlandia", "hello": "Hei, Hyvää huomenta"},
    ];
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("25 Bahasa Populer"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: ListView.builder(
        itemCount: languages.length,
        itemBuilder: (context, index) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3F), 
            borderRadius: BorderRadius.circular(16), 
            border: Border.all(color: const Color(0xFFF44336).withOpacity(0.3))
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween, 
            children: [
              Text(languages[index]["lang"]!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), 
              Text(languages[index]["hello"]!, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 12))
            ]
          ),
        ),
      ),
    );
  }
}

class PuzzleGamePage extends StatefulWidget {
  const PuzzleGamePage({super.key});
  @override
  State<PuzzleGamePage> createState() => _PuzzleGamePageState();
}

class _PuzzleGamePageState extends State<PuzzleGamePage> {
  List<int> tiles = List.generate(8, (i) => i + 1)..add(0);
  int moves = 0;
  
  @override
  void initState() { 
    super.initState(); 
    tiles.shuffle(); 
  }
  
  void _moveTile(int index) {
    int emptyIndex = tiles.indexOf(0);
    if ((index - emptyIndex).abs() == 1 || (index - emptyIndex).abs() == 3) {
      setState(() { 
        int temp = tiles[index]; 
        tiles[index] = tiles[emptyIndex]; 
        tiles[emptyIndex] = temp; 
        moves++; 
      });
    }
    if (_isSolved()) _showWinDialog();
  }
  
  bool _isSolved() { 
    for (int i = 0; i < 8; i++) if (tiles[i] != i + 1) return false; 
    return tiles[8] == 0; 
  }
  
  void _showWinDialog() { 
    showDialog(
      context: context, 
      builder: (_) => AlertDialog(
        title: const Text("🎉 Selamat!", style: TextStyle(color: Color(0xFFF44336))), 
        content: Text("Kamu menyelesaikan puzzle dalam $moves langkah!"), 
        actions: [
          TextButton(
            onPressed: () { 
              setState(() { 
                tiles.shuffle(); 
                moves = 0; 
              }); 
              Navigator.pop(_); 
            }, 
            child: const Text("Main Lagi")
          )
        ]
      )
    ); 
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Game Puzzle"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Column(
        children: [
          const SizedBox(height: 20), 
          Text("Langkah: $moves", style: const TextStyle(color: Colors.white, fontSize: 18)), 
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true, 
            physics: const NeverScrollableScrollPhysics(), 
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3, 
              crossAxisSpacing: 8, 
              mainAxisSpacing: 8
            ), 
            padding: const EdgeInsets.all(20), 
            itemCount: 9,
            itemBuilder: (context, index) => GestureDetector(
              onTap: () => _moveTile(index), 
              child: Container(
                decoration: BoxDecoration(
                  color: tiles[index] == 0 ? Colors.grey.shade800 : const Color(0xFFF44336), 
                  borderRadius: BorderRadius.circular(12)
                ), 
                child: Center(
                  child: tiles[index] == 0 
                    ? const Icon(Icons.crop_square, color: Colors.white54, size: 30) 
                    : Text("${tiles[index]}", style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold))
                )
              )
            ),
          ),
        ],
      ),
    );
  }
}

class RiddleGamePage extends StatefulWidget {
  const RiddleGamePage({super.key});
  @override
  State<RiddleGamePage> createState() => _RiddleGamePageState();
}

class _RiddleGamePageState extends State<RiddleGamePage> {
  int currentIndex = 0;
  String userAnswer = "";
  String? feedback;
  final List<Map<String, String>> riddles = [
    {"question": "Apa yang bisa naik tapi tidak bisa turun?", "answer": "umur"},
    {"question": "Benda apa yang semakin diisi semakin ringan?", "answer": "balon"},
    {"question": "Apa yang punya banyak kunci tapi tidak bisa membuka pintu?", "answer": "piano"},
  ];
  
  void _checkAnswer() {
    if (userAnswer.toLowerCase() == riddles[currentIndex]["answer"]) {
      setState(() { feedback = "✅ Benar!"; });
      Future.delayed(const Duration(seconds: 1), () { 
        if (currentIndex < riddles.length - 1) { 
          setState(() { 
            currentIndex++; 
            userAnswer = ""; 
            feedback = null; 
          }); 
        } else { 
          _showCompleteDialog(); 
        } 
      });
    } else { 
      setState(() { feedback = "❌ Salah, coba lagi!"; }); 
    }
  }
  
  void _showCompleteDialog() { 
    showDialog(
      context: context, 
      builder: (_) => AlertDialog(
        title: const Text("Selesai!", style: TextStyle(color: Color(0xFFF44336))), 
        content: const Text("Kamu berhasil menyelesaikan semua teka-teki!"), 
        actions: [
          TextButton(
            onPressed: () { 
              setState(() { 
                currentIndex = 0; 
                userAnswer = ""; 
                feedback = null; 
              }); 
              Navigator.pop(_); 
            }, 
            child: const Text("Main Lagi")
          )
        ]
      )
    ); 
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Game Teka Teki"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Padding(
        padding: const EdgeInsets.all(20), 
        child: Column(
          children: [
            Text(
              riddles[currentIndex]["question"]!, 
              style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold), 
              textAlign: TextAlign.center
            ),
            const SizedBox(height: 30),
            TextField(
              style: const TextStyle(color: Colors.white), 
              onChanged: (value) => userAnswer = value, 
              decoration: InputDecoration(
                hintText: "Masukkan jawaban...", 
                hintStyle: TextStyle(color: Colors.grey.shade500), 
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))
              )
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _checkAnswer, 
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF44336), 
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
              ), 
              child: const Text("Jawab", style: TextStyle(color: Colors.white))
            ),
            if (feedback != null) ...[
              const SizedBox(height: 20), 
              Text(feedback!, style: TextStyle(color: feedback!.contains("✅") ? Colors.green : Colors.red, fontSize: 16))
            ],
          ],
        ),
      ),
    );
  }
}

// ============ QUIZ GAME PAGE - FIXED ============
class QuizGamePage extends StatefulWidget {
  const QuizGamePage({super.key});
  @override
  State<QuizGamePage> createState() => _QuizGamePageState();
}

class _QuizGamePageState extends State<QuizGamePage> {
  int currentIndex = 0;
  int score = 0;
  int? selectedOption;
  String? feedback;
  
  final List<Map<String, dynamic>> quizzes = [
    {"question": "Siapakah presiden pertama Indonesia?", "options": ["Soekarno", "Soeharto", "BJ Habibie", "Megawati"], "answer": 0},
    {"question": "Apa ibu kota Jepang?", "options": ["Seoul", "Beijing", "Tokyo", "Bangkok"], "answer": 2},
    {"question": "Siapa pencipta lagu Indonesia Raya?", "options": ["W.R. Supratman", "Ismail Marzuki", "Chairil Anwar", "Husein Mutahar"], "answer": 0},
  ];
  
  void _checkAnswer() {
    if (selectedOption == quizzes[currentIndex]["answer"]) {
      setState(() { 
        score++; 
        feedback = "✅ Benar!"; 
      });
    } else {
      setState(() { 
        feedback = "❌ Salah! Jawaban: ${quizzes[currentIndex]["options"][quizzes[currentIndex]["answer"]]}"; 
      });
    }
    Future.delayed(const Duration(seconds: 1), () {
      if (currentIndex < quizzes.length - 1) {
        setState(() { 
          currentIndex++; 
          selectedOption = null; 
          feedback = null; 
        });
      } else {
        _showResultDialog();
      }
    });
  }
  
  void _showResultDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Hasil Quiz", style: TextStyle(color: Color(0xFFF44336))),
        content: Text("Skor kamu: $score / ${quizzes.length}", style: const TextStyle(fontSize: 18)),
        actions: [
          TextButton(
            onPressed: () {
              setState(() { 
                currentIndex = 0; 
                score = 0; 
                selectedOption = null; 
                feedback = null; 
              });
              Navigator.pop(_);
            },
            child: const Text("Main Lagi", style: TextStyle(color: Color(0xFFF44336))),
          )
        ],
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Quiz Game"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text("Soal ${currentIndex + 1}/${quizzes.length}", style: const TextStyle(color: Colors.white, fontSize: 16)),
            const SizedBox(height: 20),
            Text(
              quizzes[currentIndex]["question"].toString(), 
              style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold), 
              textAlign: TextAlign.center
            ),
            const SizedBox(height: 30),
            ...List.generate(4, (i) => RadioListTile<int>(
              title: Text(quizzes[currentIndex]["options"][i].toString(), style: const TextStyle(color: Colors.white)),
              value: i,
              groupValue: selectedOption,
              activeColor: const Color(0xFFF44336),
              onChanged: (value) => setState(() => selectedOption = value),
            )),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: selectedOption != null ? _checkAnswer : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFF44336),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
              ),
              child: const Text("Jawab", style: TextStyle(color: Colors.white)),
            ),
            if (feedback != null) ...[
              const SizedBox(height: 20),
              Text(feedback!, style: TextStyle(color: feedback!.contains("✅") ? Colors.green : Colors.red, fontSize: 16)),
            ],
          ],
        ),
      ),
    );
  }
}

class BiblePage extends StatelessWidget {
  const BiblePage({super.key});
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> bible = [
      {"verse": "Yohanes 3:16", "text": "Karena begitu besar kasih Allah akan dunia ini, sehingga Ia mengaruniakan Anak-Nya yang tunggal..."},
      {"verse": "Mazmur 23:1", "text": "TUHAN adalah gembalaku, takkan kekurangan aku."},
      {"verse": "Roma 8:28", "text": "Kita tahu sekarang, bahwa Allah turut bekerja dalam segala sesuatu untuk mendatangkan kebaikan..."},
    ];
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Alkitab"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: ListView.builder(
        itemCount: bible.length, 
        itemBuilder: (context, index) => Container(
          margin: const EdgeInsets.all(16), 
          padding: const EdgeInsets.all(16), 
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3F), 
            borderRadius: BorderRadius.circular(16), 
            border: Border.all(color: const Color(0xFFF44336).withOpacity(0.3))
          ), 
          child: Column(
            children: [
              Text(bible[index]["verse"]!, style: const TextStyle(color: Color(0xFFF44336), fontWeight: FontWeight.bold)), 
              const SizedBox(height: 8), 
              Text(bible[index]["text"]!, style: const TextStyle(color: Colors.white70))
            ]
          )
        )
      ),
    );
  }
}

class ComicPage extends StatelessWidget {
  const ComicPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Komik Populer"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: ListView.builder(
        itemCount: 10, 
        itemBuilder: (context, index) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), 
          padding: const EdgeInsets.all(16), 
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3F), 
            borderRadius: BorderRadius.circular(16)
          ), 
          child: Row(
            children: [
              Container(
                width: 60, 
                height: 80, 
                color: Colors.grey.shade800, 
                child: const Icon(Icons.menu_book, color: Colors.white54)
              ), 
              const SizedBox(width: 16), 
              Column(
                crossAxisAlignment: CrossAxisAlignment.start, 
                children: [
                  Text("Komik ${index + 1}", style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)), 
                  Text("Chapter ${index + 1} - Sedang update", style: const TextStyle(color: Colors.grey))
                ]
              )
            ]
          )
        )
      ),
    );
  }
}

class StoryPage extends StatelessWidget {
  const StoryPage({super.key});
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> stories = [
      {"title": "Si Kancil dan Buaya", "desc": "Kisah kecerdikan Si Kancil menyeberangi sungai yang penuh buaya."},
      {"title": "Bawang Merah Bawang Putih", "desc": "Kisah tentang kebaikan hati yang mendapatkan balasan."},
      {"title": "Malin Kundang", "desc": "Kisah anak durhaka yang dikutuk menjadi batu."},
      {"title": "Tangkuban Perahu", "desc": "Legenda asal usul Gunung Tangkuban Perahu."},
    ];
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Cerita Dongeng"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: ListView.builder(
        itemCount: stories.length, 
        itemBuilder: (context, index) => GestureDetector(
          onTap: () => _showStoryDetail(context, stories[index]), 
          child: Container(
            margin: const EdgeInsets.all(16), 
            padding: const EdgeInsets.all(16), 
            decoration: BoxDecoration(
              color: const Color(0xFF1A1F3F), 
              borderRadius: BorderRadius.circular(16), 
              border: Border.all(color: const Color(0xFFF44336).withOpacity(0.3))
            ), 
            child: Column(
              children: [
                Text(stories[index]["title"]!, style: const TextStyle(color: Color(0xFFF44336), fontWeight: FontWeight.bold, fontSize: 18)), 
                const SizedBox(height: 8), 
                Text(stories[index]["desc"]!, style: const TextStyle(color: Colors.white70))
              ]
            )
          )
        )
      ),
    );
  }
  
  void _showStoryDetail(BuildContext context, Map<String, String> story) { 
    showDialog(
      context: context, 
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1F3F), 
        title: Text(story["title"]!, style: const TextStyle(color: Color(0xFFF44336))), 
        content: Text(story["desc"]!, style: const TextStyle(color: Colors.white70)), 
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(_), 
            child: const Text("Tutup", style: TextStyle(color: Color(0xFFF44336)))
          )
        ]
      )
    ); 
  }
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Perpustakaan Digital"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, 
          children: [
            const Icon(Icons.library_books, color: Colors.white54, size: 80), 
            const SizedBox(height: 16), 
            const Text("Total Buku: 1,234", style: TextStyle(color: Colors.white, fontSize: 18)), 
            const Text("Tersedia untuk dibaca", style: TextStyle(color: Colors.grey)), 
            const SizedBox(height: 30), 
            ElevatedButton(
              onPressed: () {}, 
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF44336)), 
              child: const Text("Jelajahi Perpustakaan", style: TextStyle(color: Colors.white))
            )
          ]
        )
      ),
    );
  }
}

class QuranPage extends StatelessWidget {
  const QuranPage({super.key});
  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> surah = [
      {"name": "Al-Fatihah", "verses": "7 ayat", "meaning": "Pembukaan"},
      {"name": "Al-Baqarah", "verses": "286 ayat", "meaning": "Sapi Betina"},
      {"name": "Ali Imran", "verses": "200 ayat", "meaning": "Keluarga Imran"},
      {"name": "An-Nisa", "verses": "176 ayat", "meaning": "Wanita"},
      {"name": "Al-Maidah", "verses": "120 ayat", "meaning": "Jamuan"},
    ];
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Al-Qur'an Digital"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: ListView.builder(
        itemCount: surah.length, 
        itemBuilder: (context, index) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), 
          padding: const EdgeInsets.all(16), 
          decoration: BoxDecoration(
            color: const Color(0xFF1A1F3F), 
            borderRadius: BorderRadius.circular(16)
          ), 
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween, 
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start, 
                children: [
                  Text(surah[index]["name"]!, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)), 
                  Text(surah[index]["meaning"]!, style: const TextStyle(color: Colors.grey, fontSize: 12))
                ]
              ), 
              Text(surah[index]["verses"]!, style: const TextStyle(color: Color(0xFFF44336)))
            ]
          )
        )
      ),
    );
  }
}

class ChatAIPage extends StatefulWidget {
  const ChatAIPage({super.key});
  @override
  State<ChatAIPage> createState() => _ChatAIPageState();
}

class _ChatAIPageState extends State<ChatAIPage> {
  final TextEditingController _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  
  void _sendMessage() {
    if (_controller.text.trim().isEmpty) return;
    setState(() => _messages.add({"role": "user", "content": _controller.text}));
    String reply = _getAIResponse(_controller.text);
    setState(() => _messages.add({"role": "assistant", "content": reply}));
    _controller.clear();
  }
  
  String _getAIResponse(String input) {
    if (input.toLowerCase().contains("halo") || input.toLowerCase().contains("hai")) return "Halo! Ada yang bisa saya bantu?";
    if (input.toLowerCase().contains("terima kasih")) return "Sama-sama! Senang bisa membantu.";
    if (input.toLowerCase().contains("apa kabar")) return "Saya baik, terima kasih! Bagaimana kabar Anda?";
    return "Maaf, saya masih dalam pengembangan. Silakan coba pertanyaan lain.";
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Chat AI Assistant"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true, 
              itemCount: _messages.length, 
              itemBuilder: (context, index) { 
                final msg = _messages[_messages.length - 1 - index]; 
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), 
                  alignment: msg["role"] == "user" ? Alignment.centerRight : Alignment.centerLeft, 
                  child: Container(
                    padding: const EdgeInsets.all(12), 
                    decoration: BoxDecoration(
                      color: msg["role"] == "user" ? const Color(0xFFF44336) : const Color(0xFF1A1F3F), 
                      borderRadius: BorderRadius.circular(16)
                    ), 
                    child: Text(msg["content"]!, style: const TextStyle(color: Colors.white))
                  )
                ); 
              }
            )
          ),
          Padding(
            padding: const EdgeInsets.all(16), 
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller, 
                    style: const TextStyle(color: Colors.white), 
                    decoration: InputDecoration(
                      hintText: "Tanyakan sesuatu...", 
                      hintStyle: TextStyle(color: Colors.grey.shade500), 
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(24))
                    )
                  )
                ), 
                const SizedBox(width: 12), 
                IconButton(
                  onPressed: _sendMessage, 
                  icon: const Icon(Icons.send, color: Color(0xFFF44336))
                )
              ],
            )
          ),
        ],
      ),
    );
  }
}

class HTMLSourcePage extends StatelessWidget {
  const HTMLSourcePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Source HTML"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: const Center(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16), 
          child: SelectableText(
            '<!DOCTYPE html>\n<html>\n<head><title>Halaman Saya</title></head>\n<body><h1>Selamat Datang</h1><p>Ini adalah contoh kode HTML.</p></body>\n</html>', 
            style: TextStyle(color: Colors.white, fontFamily: 'monospace', fontSize: 12)
          )
        )
      ),
    );
  }
}

class SnakeGamePage extends StatefulWidget {
  const SnakeGamePage({super.key});
  @override
  State<SnakeGamePage> createState() => _SnakeGamePageState();
}

class _SnakeGamePageState extends State<SnakeGamePage> {
  List<List<int>> snake = [[5, 5]];
  List<int> food = [10, 10];
  String direction = "RIGHT";
  int score = 0;
  bool isGameOver = false;
  
  @override
  void initState() { 
    super.initState(); 
    _generateFood(); 
    _startGame(); 
  }
  
  void _startGame() { 
    Future.delayed(const Duration(milliseconds: 300), _move); 
  }
  
  void _move() {
    if (isGameOver) return;
    setState(() {
      List<int> newHead = List.from(snake.first);
      switch (direction) { 
        case "UP": newHead[1]--; break; 
        case "DOWN": newHead[1]++; break; 
        case "LEFT": newHead[0]--; break; 
        case "RIGHT": newHead[0]++; break; 
      }
      if (newHead[0] == food[0] && newHead[1] == food[1]) { 
        snake.insert(0, newHead); 
        score++; 
        _generateFood(); 
      } else { 
        snake.insert(0, newHead); 
        snake.removeLast(); 
      }
      if (_checkCollision()) { 
        isGameOver = true; 
        _showGameOver(); 
      }
    });
    if (!isGameOver) Future.delayed(const Duration(milliseconds: 300), _move);
  }
  
  bool _checkCollision() {
    if (snake.first[0] < 0 || snake.first[0] >= 20 || snake.first[1] < 0 || snake.first[1] >= 20) return true;
    for (int i = 1; i < snake.length; i++) if (snake.first[0] == snake[i][0] && snake.first[1] == snake[i][1]) return true;
    return false;
  }
  
  void _generateFood() { 
    food = [Random().nextInt(20), Random().nextInt(20)]; 
  }
  
  void _showGameOver() { 
    showDialog(
      context: context, 
      builder: (_) => AlertDialog(
        title: const Text("Game Over!", style: TextStyle(color: Color(0xFFF44336))), 
        content: Text("Skor: $score", style: const TextStyle(color: Colors.white)), 
        actions: [
          TextButton(
            onPressed: () { 
              setState(() { 
                snake = [[5, 5]]; 
                score = 0; 
                direction = "RIGHT"; 
                isGameOver = false; 
                _generateFood(); 
                _startGame(); 
              }); 
              Navigator.pop(_); 
            }, 
            child: const Text("Main Lagi")
          )
        ]
      )
    ); 
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: const Text("Game Ular"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Column(
        children: [
          const SizedBox(height: 20), 
          Text("Skor: $score", style: const TextStyle(color: Colors.white, fontSize: 24)), 
          const SizedBox(height: 20),
          Expanded(
            child: GestureDetector(
              onPanUpdate: (details) { 
                if (details.delta.dx.abs() > details.delta.dy.abs()) { 
                  if (details.delta.dx > 0 && direction != "LEFT") direction = "RIGHT"; 
                  else if (details.delta.dx < 0 && direction != "RIGHT") direction = "LEFT"; 
                } else { 
                  if (details.delta.dy > 0 && direction != "UP") direction = "DOWN"; 
                  else if (details.delta.dy < 0 && direction != "DOWN") direction = "UP"; 
                } 
              }, 
              child: GridView.builder(
                physics: const NeverScrollableScrollPhysics(), 
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 20), 
                itemCount: 400, 
                itemBuilder: (context, index) { 
                  int x = index % 20, y = index ~/ 20; 
                  bool isSnake = snake.any((s) => s[0] == x && s[1] == y); 
                  bool isFood = food[0] == x && food[1] == y; 
                  return Container(
                    margin: const EdgeInsets.all(1), 
                    decoration: BoxDecoration(
                      color: isSnake ? const Color(0xFFF44336) : (isFood ? Colors.green : Colors.grey.shade800), 
                      borderRadius: BorderRadius.circular(4)
                    )
                  ); 
                }
              )
            )
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center, 
            children: [
              _buildDirectionButton("⬆️", "UP"), 
              const SizedBox(width: 20), 
              _buildDirectionButton("⬅️", "LEFT"), 
              const SizedBox(width: 20), 
              _buildDirectionButton("➡️", "RIGHT"), 
              const SizedBox(width: 20), 
              _buildDirectionButton("⬇️", "DOWN")
            ]
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
  
  Widget _buildDirectionButton(String icon, String dir) { 
    return ElevatedButton(
      onPressed: () { 
        if (dir == "UP" && direction != "DOWN") direction = "UP"; 
        else if (dir == "DOWN" && direction != "UP") direction = "DOWN"; 
        else if (dir == "LEFT" && direction != "RIGHT") direction = "LEFT"; 
        else if (dir == "RIGHT" && direction != "LEFT") direction = "RIGHT"; 
      }, 
      style: ElevatedButton.styleFrom(
        backgroundColor: const Color(0xFF1A1F3F), 
        shape: const CircleBorder()
      ), 
      child: Text(icon, style: const TextStyle(fontSize: 24))
    ); 
  }
}

class ServerLagPage extends StatelessWidget {
  final String game;
  const ServerLagPage({super.key, required this.game});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: AppBar(
        title: Text("$game Server Lag"), 
        backgroundColor: const Color(0xFFF44336)
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, 
          children: [
            const Icon(Icons.speed, color: Colors.white54, size: 80), 
            const SizedBox(height: 16), 
            Text("$game Server Lag Tools", style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)), 
            const SizedBox(height: 8), 
            const Text("Fitur akan segera hadir", style: TextStyle(color: Colors.grey, fontSize: 16)), 
            const SizedBox(height: 30), 
            ElevatedButton(
              onPressed: () => Navigator.pop(context), 
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF44336)), 
              child: const Text("Kembali", style: TextStyle(color: Colors.white))
            )
          ]
        )
      ),
    );
  }
}

// ============ DASHBOARD PAGE UTAMA ============
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController animationController;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;
  WebSocketChannel? channel;
  int _reconnectAttempt = 0;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? profileImage;

  int bottomNavIndex = 0;
  Widget selectedPage = const SizedBox();

  int onlineUsers = 0;
  int activeConnections = 0;

  static const Color bgDark = Color(0xFF0A0E27);
  static const Color accentRed = Color(0xFFF44336);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color softRed = Color(0xFFEF5350);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);

  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);

  LinearGradient get redGradient => const LinearGradient(
    colors: [Color(0xFFF44336), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  LinearGradient get secondaryGradient => const LinearGradient(
    colors: [Color(0xFFB71C1C), Color(0xFFEF5350)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  List<Map<String, dynamic>> get extraTools {
    return [
      {"icon": Icons.translate, "label": "Belajar 25 Bahasa", "color": Colors.deepPurple, "page": const LanguagePage()},
      {"icon": Icons.extension, "label": "Game Puzzle", "color": Colors.orange, "page": const PuzzleGamePage()},
      {"icon": Icons.quiz, "label": "Game Teka Teki", "color": Colors.teal, "page": const RiddleGamePage()},
      {"icon": Icons.school, "label": "Quiz", "color": Colors.blue, "page": const QuizGamePage()},
      {"icon": Icons.access_time, "label": "Jadwal Sholat", "color": Colors.green, "page": const JadwalSholatPage()},
      {"icon": FontAwesomeIcons.bible, "label": "Alkitab", "color": Colors.brown, "page": const BiblePage()},
      {"icon": Icons.menu_book, "label": "Komik", "color": Colors.pink, "page": const ComicPage()},
      {"icon": Icons.auto_stories, "label": "Cerita Dongeng", "color": Colors.indigo, "page": const StoryPage()},
      {"icon": Icons.library_books, "label": "Perpustakaan", "color": Colors.amber, "page": const LibraryPage()},
      {"icon": Icons.mosque, "label": "Alquran", "color": Colors.teal, "page": const QuranPage()},
      {"icon": Icons.music_note, "label": "Spotify", "color": Colors.green, "page": const SpotifyMusicPage()},
      {"icon": Icons.people, "label": "Nama Nabi", "color": Colors.cyan, "page": null, "isDialog": true, "dialogType": "prophets"},
      {"icon": Icons.star, "label": "Asmaul Husna", "color": Colors.purple, "page": null, "isDialog": true, "dialogType": "asmaul"},
      {"icon": Icons.chat, "label": "Chat AI", "color": Colors.blueGrey, "page": const ChatAIPage()},
      {"icon": Icons.code, "label": "Source HTML", "color": Colors.red, "page": const HTMLSourcePage()},
      {"icon": Icons.lock_open, "label": "ENC File", "color": Colors.orange, "page": null, "isDialog": true, "dialogType": "enc"},
      {"icon": Icons.no_encryption, "label": "NO ENC File", "color": Colors.orangeAccent, "page": null, "isDialog": true, "dialogType": "no_enc"},
      {"icon": Icons.games, "label": "Game Ular", "color": Colors.lime, "page": const SnakeGamePage()},
      {"icon": Icons.speed, "label": "MLBB Server Lag", "color": Colors.blue, "page": const ServerLagPage(game: "MLBB")},
      {"icon": Icons.flash_on, "label": "FreeFire Server Lag", "color": Colors.red, "page": const ServerLagPage(game: "FreeFire")},
    ];
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();
    fadeAnimation = CurvedAnimation(parent: animationController, curve: Curves.easeOut);
    slideAnimation = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero).animate(
      CurvedAnimation(parent: animationController, curve: Curves.easeOutCubic),
    );
    selectedPage = buildHomePage();
    initAndroidIdAndConnect();
    loadProfileImage();
    _startHeartbeat();
  }

  void _startHeartbeat() {
    Timer.periodic(const Duration(seconds: 30), (_) async {
      try {
        final res = await http.get(Uri.parse('$kBaseUrl/ping')).timeout(const Duration(seconds: 5));
        if (res.statusCode != 200) {
          _reconnectAttempt++;
          if (_reconnectAttempt > 3) _reconnectWebSocket();
        } else {
          _reconnectAttempt = 0;
        }
      } catch (_) {
        _reconnectAttempt++;
        if (_reconnectAttempt > 3) _reconnectWebSocket();
      }
    });
  }

  void _reconnectWebSocket() {
    channel?.sink.close();
    connectToWebSocket();
  }

  Future<void> loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (!mounted) return;
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() { profileImage = File(imagePath); });
    }
  }

  Future<void> initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    connectToWebSocket();
  }

  void connectToWebSocket() {
    try {
      channel = WebSocketChannel.connect(Uri.parse('wss://ws-nitz.pterodactyl.panelkuy.my.id'));
      channel?.sink.add(jsonEncode({"type": "validate", "key": sessionKey, "androidId": androidId}));
      channel?.sink.add(jsonEncode({"type": "stats"}));
      channel?.stream.listen((event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo') {
          if (data['valid'] == false) {
            if (data['reason'] == 'androidIdMismatch') {
              handleInvalidSession("Your account has logged on another device.");
            } else if (data['reason'] == 'keyInvalid') {
              handleInvalidSession("Key is not valid. Please login again.");
            }
          }
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }, onError: (error) {
        _reconnectAttempt++;
        if (_reconnectAttempt > 3) {
          Future.delayed(const Duration(seconds: 5), () => _reconnectWebSocket());
        }
      });
    } catch (e) {
      Future.delayed(const Duration(seconds: 5), () => _reconnectWebSocket());
    }
  }

  Future<void> openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28), side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5)),
        title: Row(children: [
          Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.orange.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 24)),
          const SizedBox(width: 12),
          const Text("Session Expired", style: TextStyle(color: Color(0xFFF44336), fontWeight: FontWeight.w700, fontSize: 18)),
        ]),
        content: Text(message, style: const TextStyle(color: Color(0xFF94A3B8), fontSize: 14)),
        actions: [
          Container(
            decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(16)),
            child: TextButton(
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => const LoginPage()),
                  (route) => false,
                );
              },
              child: const Text("OK", style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }

  void onBottomNavTapped(int index) {
    setState(() {
      bottomNavIndex = index;
      if (index == 0) {
        selectedPage = buildHomePage();
      } else if (index == 1) {
        selectedPage = HomePage(username: username, password: password, listBug: listBug, role: role, expiredDate: expiredDate, sessionKey: sessionKey);
      } else if (index == 2) {
        selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role, listDoos: listDoos);
      } else if (index == 4) {
        selectedPage = DeviceDashboardPage(username: username, role: role, sessionKey: sessionKey);
      }
    });
  }

  void onSidebarTabSelected(int index) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 200), () {
      setState(() {
        if (index == 1) selectedPage = SellerPage(keyToken: sessionKey);
        else if (index == 2) selectedPage = AdminPage(sessionKey: sessionKey);
        else if (index == 3) selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      });
    });
  }

  List<Map<String, dynamic>> get quickActions {
    return [
      {"icon": Icons.bug_report_rounded, "label": "Manage Bug", "color": accentRed, "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => BugSenderPage(sessionKey: sessionKey, username: username, role: role))); }},
      {"icon": FontAwesomeIcons.telegram, "label": "Join Channel", "color": const Color(0xFF0088cc), "onTap": () => openUrl("https://t.me/RevXteam")},
      {"icon": Icons.chat_rounded, "label": "Room Public", "color": Colors.purple, "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => const RoomPublicPage())); }},
      {"icon": Icons.live_tv_rounded, "label": "Anime Stream", "color": Colors.deepOrange, "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => const HomeAnimePage())); }},
      {"icon": Icons.movie_rounded, "label": "Anime List", "color": Colors.red, "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => const HomeAnimePage())); }},
      {"icon": Icons.favorite_rounded, "label": "Thanks To", "color": Colors.pink, "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => const ThanksToPage())); }},
      {"icon": Icons.music_note_rounded, "label": "Spotify", "color": Colors.green, "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => const SpotifyMusicPage())); }},
      {"icon": Icons.devices_rounded, "label": "RAT Control", "color": const Color(0xFF00BCD4), "onTap": () { Navigator.push(context, MaterialPageRoute(builder: (context) => DeviceDashboardPage(username: username, role: role, sessionKey: sessionKey))); }},
    ];
  }

  Widget buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [accentRed.withOpacity(0.1), darkRed.withOpacity(0.05)])),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Welcome Back,", style: TextStyle(color: Color(0xFF94A3B8), fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.5)),
                const SizedBox(height: 4),
                ShaderMask(shaderCallback: (bounds) => redGradient.createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)), child: Text(username, style: const TextStyle(color: Color(0xFFFFFFFF), fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 0.5))),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(gradient: secondaryGradient, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 2))]),
                  child: Text(role.toUpperCase(), style: const TextStyle(color: Color(0xFFFFFFFF), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1)),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Expanded(child: buildModernStatsCard(icon: Icons.people_rounded, label: "Online Users", value: "$onlineUsers", color: accentRed)),
                const SizedBox(width: 16),
                Expanded(child: buildModernStatsCard(icon: Icons.link_rounded, label: "Active Connections", value: "$activeConnections", color: softRed)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: TweenAnimationBuilder(
              duration: const Duration(milliseconds: 800),
              tween: Tween<double>(begin: 0, end: 1),
              builder: (context, double value, child) => Opacity(opacity: value, child: Transform.translate(offset: Offset(0, 20 * (1 - value)), child: child)),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(gradient: LinearGradient(colors: [accentRed.withOpacity(0.15), darkRed.withOpacity(0.1)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(28), border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5), boxShadow: [BoxShadow(color: accentRed.withOpacity(0.2), blurRadius: 15, spreadRadius: 0)]),
                child: Row(
                  children: [
                    Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: accentRed.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))]), child: const Icon(Icons.calendar_today, color: Color(0xFFFFFFFF), size: 22)),
                    const SizedBox(width: 16),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text("Expiration Date", style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12)), const SizedBox(height: 6), Text(expiredDate, style: const TextStyle(color: Color(0xFFFFFFFF), fontSize: 18, fontWeight: FontWeight.bold))])),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8), decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 6)]), child: const Text("ACTIVE", style: TextStyle(color: Color(0xFFFFFFFF), fontSize: 11, fontWeight: FontWeight.bold))),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: Stack(
                children: [
                  Container(height: 200, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [darkRed, accentRed.withOpacity(0.5)])), child: const Center(child: Icon(Icons.image, color: Color(0xFFFFFFFF), size: 50))),
                  Container(height: 200, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black.withOpacity(0.7), Colors.transparent]))),
                  const Positioned(left: 20, bottom: 20, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text("DirzZX Beta", style: TextStyle(color: Color(0xFFFFFFFF), fontSize: 24, fontWeight: FontWeight.bold, shadows: [Shadow(offset: Offset(1, 1), blurRadius: 4, color: Colors.black45)])), SizedBox(height: 4), Text("Beta Version Project", style: TextStyle(color: Color(0xFF94A3B8), fontSize: 12, fontWeight: FontWeight.w500, shadows: [Shadow(offset: Offset(1, 1), blurRadius: 3, color: Colors.black45)]))])),
                ],
              ),
            ),
          ),
          const SizedBox(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [Container(width: 4, height: 28, decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(2))), const SizedBox(width: 12), const Text("QUICK ACTIONS", style: TextStyle(color: Color(0xFF94A3B8), fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.5)), const Spacer(), Icon(Icons.touch_app_rounded, color: accentRed, size: 18)]),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.85),
              itemCount: quickActions.length,
              itemBuilder: (context, index) {
                final action = quickActions[index];
                return buildModernQuickAction(icon: action['icon'] as IconData, label: action['label'] as String, color: action['color'] as Color, onTap: action['onTap'] as VoidCallback);
              },
            ),
          ),
          const SizedBox(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [Container(width: 4, height: 28, decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(2))), const SizedBox(width: 12), const Text("ISLAMIC FEATURES", style: TextStyle(color: Color(0xFF94A3B8), fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.5))]),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Expanded(child: buildModernIslamicCard(icon: Icons.access_time_rounded, label: "Jadwal Sholat", subtitle: "Prayer Schedule", color: Colors.green, gradientColors: const [Color(0xFF00C853), Color(0xFF00E676)], onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const JadwalSholatPage())))),
                const SizedBox(width: 16),
                Expanded(child: buildModernIslamicCard(icon: Icons.menu_book_rounded, label: "Hadis", subtitle: "Islamic Hadith", color: Colors.teal, gradientColors: const [Color(0xFF00897B), Color(0xFF00ACC1)], onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => const HadisPage())))),
              ],
            ),
          ),
          const SizedBox(height: 32),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(children: [Container(width: 4, height: 28, decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(2))), const SizedBox(width: 12), const Text("EXTRA TOOLS", style: TextStyle(color: Color(0xFF94A3B8), fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 1.5)), const Spacer(), Icon(Icons.build_circle, color: accentRed, size: 18)]),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.85),
              itemCount: extraTools.length,
              itemBuilder: (context, index) {
                final tool = extraTools[index];
                return buildModernQuickAction(
                  icon: tool['icon'] as IconData,
                  label: tool['label'] as String,
                  color: tool['color'] as Color,
                  onTap: () {
                    if (tool['page'] != null) {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => tool['page'] as Widget));
                    } else if (tool['isDialog'] == true) {
                      if (tool['dialogType'] == "prophets") {
                        _showProphetsDialog();
                      } else if (tool['dialogType'] == "asmaul") {
                        _showAsmaulHusnaDialog();
                      } else if (tool['dialogType'] == "enc") {
                        _showEncFileDialog();
                      } else if (tool['dialogType'] == "no_enc") {
                        _showNoEncFileDialog();
                      }
                    }
                  },
                );
              },
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  void _showProphetsDialog() {
    final List<Map<String, String>> prophets = [
      {"name": "Nabi Adam AS", "desc": "Nabi pertama"}, {"name": "Nabi Idris AS", "desc": "Pandai menulis"},
      {"name": "Nabi Nuh AS", "desc": "Membangun bahtera"}, {"name": "Nabi Hud AS", "desc": "Kaum 'Ad"},
      {"name": "Nabi Shaleh AS", "desc": "Kaum Tsamud"}, {"name": "Nabi Ibrahim AS", "desc": "Khalilullah"},
      {"name": "Nabi Luth AS", "desc": "Kaum Sodom"}, {"name": "Nabi Ishaq AS", "desc": "Putra Ibrahim"},
      {"name": "Nabi Ismail AS", "desc": "Putra Ibrahim"}, {"name": "Nabi Yaqub AS", "desc": "Ayah Yusuf"},
      {"name": "Nabi Yusuf AS", "desc": "Penafsir mimpi"}, {"name": "Nabi Ayyub AS", "desc": "Sabar"},
      {"name": "Nabi Syuaib AS", "desc": "Pandai pidato"}, {"name": "Nabi Musa AS", "desc": "Menerima Taurat"},
      {"name": "Nabi Harun AS", "desc": "Pendamping Musa"}, {"name": "Nabi Dzulkifli AS", "desc": "Sabar"},
      {"name": "Nabi Daud AS", "desc": "Menerima Zabur"}, {"name": "Nabi Sulaiman AS", "desc": "Bicara binatang"},
      {"name": "Nabi Ilyas AS", "desc": "Kaum Ba'labak"}, {"name": "Nabi Ilyasa AS", "desc": "Penerus Ilyas"},
      {"name": "Nabi Yunus AS", "desc": "Ditelan ikan"}, {"name": "Nabi Zakaria AS", "desc": "Penjaga Maryam"},
      {"name": "Nabi Yahya AS", "desc": "Putra Zakaria"}, {"name": "Nabi Isa AS", "desc": "Menerima Injil"},
      {"name": "Nabi Muhammad SAW", "desc": "Nabi terakhir"},
    ];
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text("25 Nama Nabi", style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.bold)),
        content: SizedBox(width: double.maxFinite, height: 400, child: ListView.builder(itemCount: prophets.length, itemBuilder: (context, index) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Text(prophets[index]["name"]!, style: const TextStyle(color: Color(0xFFF44336), fontWeight: FontWeight.bold)), const SizedBox(width: 12), Text(prophets[index]["desc"]!, style: const TextStyle(color: Color(0xFF94A3B8)))])))),
        actions: [TextButton(onPressed: () => Navigator.pop(_), child: const Text("Tutup", style: TextStyle(color: Color(0xFFF44336))))],
      ),
    );
  }

  void _showAsmaulHusnaDialog() {
    final List<Map<String, String>> asmaul = [
      {"name": "Ar-Rahman", "meaning": "Maha Pengasih"}, {"name": "Ar-Rahim", "meaning": "Maha Penyayang"},
      {"name": "Al-Malik", "meaning": "Maha Merajai"}, {"name": "Al-Quddus", "meaning": "Maha Suci"},
      {"name": "As-Salam", "meaning": "Maha Sejahtera"}, {"name": "Al-Mu'min", "meaning": "Maha Memberi Keamanan"},
      {"name": "Al-Muhaymin", "meaning": "Maha Pemelihara"}, {"name": "Al-Aziz", "meaning": "Maha Perkasa"},
      {"name": "Al-Jabbar", "meaning": "Maha Perkasa"}, {"name": "Al-Mutakabbir", "meaning": "Maha Megah"},
      {"name": "Al-Khaliq", "meaning": "Maha Pencipta"}, {"name": "Al-Bari'", "meaning": "Maha Mengadakan"},
      {"name": "Al-Musawwir", "meaning": "Maha Pembentuk"}, {"name": "Al-Ghaffar", "meaning": "Maha Pengampun"},
      {"name": "Al-Qahhar", "meaning": "Maha Menundukkan"}, {"name": "Al-Wahhab", "meaning": "Maha Pemberi"},
      {"name": "Ar-Razzaq", "meaning": "Maha Pemberi Rezeki"}, {"name": "Al-Fattah", "meaning": "Maha Pembuka"},
      {"name": "Al-Alim", "meaning": "Maha Mengetahui"}, {"name": "Al-Qabid", "meaning": "Maha Penyempit"},
      {"name": "Al-Basit", "meaning": "Maha Melapangkan"},
    ];
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text("Asmaul Husna", style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.bold)),
        content: SizedBox(width: double.maxFinite, height: 400, child: ListView.builder(itemCount: asmaul.length, itemBuilder: (context, index) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(children: [Text(asmaul[index]["name"]!, style: const TextStyle(color: Color(0xFFF44336), fontWeight: FontWeight.bold)), const SizedBox(width: 12), Text(asmaul[index]["meaning"]!, style: const TextStyle(color: Color(0xFF94A3B8)))])))),
        actions: [TextButton(onPressed: () => Navigator.pop(_), child: const Text("Tutup", style: TextStyle(color: Color(0xFFF44336))))],
      ),
    );
  }

  void _showEncFileDialog() {
    final TextEditingController inputController = TextEditingController();
    String? output;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            backgroundColor: glassPrimary,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Text("ENC File - Encode", style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.bold)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: inputController, style: const TextStyle(color: Color(0xFFFFFFFF)), decoration: InputDecoration(hintText: "Masukkan teks", hintStyle: TextStyle(color: Color(0xFF94A3B8)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
                const SizedBox(height: 12),
                if (output != null) ...[
                  const Text("Hasil:", style: TextStyle(color: Color(0xFFFFFFFF))),
                  Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)), child: SelectableText(output!, style: const TextStyle(color: Color(0xFFF44336)))),
                ],
              ],
            ),
            actions: [
              TextButton(onPressed: () { if (inputController.text.isNotEmpty) { setStateDialog(() { output = base64Encode(utf8.encode(inputController.text)); }); } }, child: const Text("Encode", style: TextStyle(color: Color(0xFFF44336)))),
              TextButton(onPressed: () => Navigator.pop(_), child: const Text("Tutup", style: TextStyle(color: Color(0xFFF44336)))),
            ],
          );
        },
      ),
    );
  }

  void _showNoEncFileDialog() {
    final TextEditingController inputController = TextEditingController();
    String? output;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setStateDialog) {
          return AlertDialog(
            backgroundColor: glassPrimary,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
            title: const Text("NO ENC File - Decode", style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.bold)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: inputController, style: const TextStyle(color: Color(0xFFFFFFFF)), decoration: InputDecoration(hintText: "Masukkan Base64", hintStyle: TextStyle(color: Color(0xFF94A3B8)), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
                const SizedBox(height: 12),
                if (output != null) ...[
                  const Text("Hasil:", style: TextStyle(color: Color(0xFFFFFFFF))),
                  Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(12)), child: SelectableText(output!, style: const TextStyle(color: Color(0xFFF44336)))),
                ],
              ],
            ),
            actions: [
              TextButton(onPressed: () { if (inputController.text.isNotEmpty) { try { setStateDialog(() { output = utf8.decode(base64Decode(inputController.text)); }); } catch (e) { setStateDialog(() { output = "Error: Format tidak valid"; }); } } }, child: const Text("Decode", style: TextStyle(color: Color(0xFFF44336)))),
              TextButton(onPressed: () => Navigator.pop(_), child: const Text("Tutup", style: TextStyle(color: Color(0xFFF44336)))),
            ],
          );
        },
      ),
    );
  }

  Widget buildModernStatsCard({required IconData icon, required String label, required String value, required Color color}) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double scale, child) => Transform.scale(scale: scale, child: child),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(gradient: LinearGradient(colors: [glassPrimary, glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: Color(0xFFFFFFFF).withOpacity(0.1), width: 1)),
        child: Row(
          children: [
            Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(gradient: LinearGradient(colors: [color, color.withOpacity(0.7)]), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: Color(0xFFFFFFFF), size: 22)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: TextStyle(color: Color(0xFF94A3B8), fontSize: 11, fontWeight: FontWeight.w500)), const SizedBox(height: 4), Text(value, style: TextStyle(color: color, fontSize: 22, fontWeight: FontWeight.bold))])),
          ],
        ),
      ),
    );
  }

  Widget buildModernQuickAction({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(gradient: LinearGradient(colors: [glassPrimary, glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(20), border: Border.all(color: color.withOpacity(0.3), width: 1)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(gradient: LinearGradient(colors: [color.withOpacity(0.2), color.withOpacity(0.1)]), borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: color, size: 28)),
            const SizedBox(height: 10),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: Text(label, style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.w600, fontSize: 10), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis)),
          ],
        ),
      ),
    );
  }

  Widget buildModernIslamicCard({required IconData icon, required String label, required String subtitle, required Color color, required List<Color> gradientColors, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(gradient: LinearGradient(colors: [glassPrimary, glassSecondary], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(24), border: Border.all(color: Color(0xFFFFFFFF).withOpacity(0.1), width: 1)),
        child: Column(
          children: [
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(gradient: LinearGradient(colors: gradientColors), borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: gradientColors[0].withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))]), child: Icon(icon, color: Color(0xFFFFFFFF), size: 28)),
            const SizedBox(height: 12),
            Text(label, style: const TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.w700, fontSize: 14), textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(subtitle, style: TextStyle(color: Color(0xFF94A3B8), fontSize: 10), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgDark,
      width: MediaQuery.of(context).size.width * 0.85,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(0), bottomRight: Radius.circular(0))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 280,
            decoration: BoxDecoration(gradient: redGradient),
            child: SafeArea(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 100, height: 100,
                      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Color(0xFFFFFFFF), width: 3), boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 20, spreadRadius: 5)]),
                      child: ClipOval(
                        child: profileImage != null ? Image.file(profileImage!, fit: BoxFit.cover) : Container(decoration: BoxDecoration(gradient: secondaryGradient), child: Icon(FontAwesomeIcons.userAstronaut, size: 45, color: primaryWhite.withOpacity(0.9))),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(username, style: const TextStyle(color: Color(0xFFFFFFFF), fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 0.5)),
                    const SizedBox(height: 6),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5), decoration: BoxDecoration(color: primaryWhite.withOpacity(0.15), borderRadius: BorderRadius.circular(20), border: Border.all(color: primaryWhite.withOpacity(0.2))), child: Text(role.toUpperCase(), style: const TextStyle(color: Color(0xFFFFFFFF), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 1))),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: bgDark,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  if (role == "reseller") buildGlassMenuItem(icon: Icons.storefront_rounded, label: "Seller Page", onTap: () => onSidebarTabSelected(1)),
                  if (role == "admin") buildGlassMenuItem(icon: Icons.admin_panel_settings_rounded, label: "Admin Page", onTap: () => onSidebarTabSelected(2)),
                  if (role == "owner") buildGlassMenuItem(icon: Icons.workspace_premium_rounded, label: "Owner Page", onTap: () => onSidebarTabSelected(3)),
                  buildGlassMenuItem(icon: Icons.history_rounded, label: "Riwayat Aktivitas", onTap: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (context) => RiwayatPage(sessionKey: sessionKey, role: role))); }),
                  const Divider(color: Colors.white10, height: 32, thickness: 0.5),
                  buildGlassMenuItem(icon: Icons.logout_rounded, label: "Log Out", isLogout: true, onTap: () async { Navigator.pop(context); final prefs = await SharedPreferences.getInstance(); await prefs.clear(); if (!mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context) => const LoginPage()), (route) => false); }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildGlassMenuItem({required IconData icon, required String label, required VoidCallback onTap, bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(color: isLogout ? Colors.red.withOpacity(0.1) : glassSecondary, borderRadius: BorderRadius.circular(16), border: isLogout ? null : Border.all(color: primaryWhite.withOpacity(0.05))),
      child: ListTile(
        leading: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: isLogout ? Colors.red.withOpacity(0.15) : accentRed.withOpacity(0.1), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: isLogout ? Colors.redAccent : accentRed, size: 20)),
        title: Text(label, style: TextStyle(color: isLogout ? Colors.redAccent : primaryWhite, fontWeight: FontWeight.w600, fontSize: 14, letterSpacing: 0.3)),
        trailing: isLogout ? null : Icon(Icons.chevron_right_rounded, color: softGrey, size: 20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10), decoration: BoxDecoration(gradient: redGradient, borderRadius: BorderRadius.circular(30), boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 2))]), child: const Text("DirzZX Beta", style: TextStyle(color: Color(0xFFFFFFFF), fontWeight: FontWeight.w700, fontSize: 14, letterSpacing: 1.5))),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Color(0xFFFFFFFF)),
        actions: [
          Container(margin: const EdgeInsets.only(right: 8), decoration: BoxDecoration(color: glassSecondary, borderRadius: BorderRadius.circular(14), border: Border.all(color: primaryWhite.withOpacity(0.08))), child: IconButton(icon: Icon(Icons.headset_mic_rounded, color: accentRed, size: 20), tooltip: 'Customer Service', onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (context) => const ContactPage())); })),
          Container(margin: const EdgeInsets.only(right: 12), decoration: BoxDecoration(color: glassSecondary, borderRadius: BorderRadius.circular(14), border: Border.all(color: primaryWhite.withOpacity(0.08))), child: IconButton(icon: Icon(FontAwesomeIcons.circleUser, color: accentRed, size: 20), tooltip: 'My Profile', onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey))); })),
        ],
      ),
      drawer: buildCustomDrawer(),
      body: Container(
        decoration: BoxDecoration(gradient: RadialGradient(center: Alignment.topLeft, radius: 1.5, colors: [accentRed.withOpacity(0.15), bgDark, bgDark], stops: const [0.0, 0.4, 1.0])),
        child: CustomPaint(painter: GridPainter(), child: SafeArea(child: FadeTransition(opacity: fadeAnimation, child: SlideTransition(position: slideAnimation, child: selectedPage)))),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(color: glassPrimary, border: Border(top: BorderSide(color: primaryWhite.withOpacity(0.08))), borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24))),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentRed,
          unselectedItemColor: softGrey,
          currentIndex: bottomNavIndex,
          onTap: onBottomNavTapped,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11, letterSpacing: 0.5),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: "Home"),
            BottomNavigationBarItem(icon: Icon(FontAwesomeIcons.whatsapp), label: "WhatsApp"),
            BottomNavigationBarItem(icon: Icon(Icons.notifications_active_rounded), label: "Info"),
            BottomNavigationBarItem(icon: Icon(Icons.build_rounded), label: "Tools"),
            BottomNavigationBarItem(icon: Icon(Icons.devices_rounded), label: "RAT"),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel?.sink.close(status.goingAway);
    animationController.dispose();
    super.dispose();
  }
}

class GridPainter extends CustomPainter {
  static const Color accentRed = Color(0xFFF44336);
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.02)..strokeWidth = 0.8..style = PaintingStyle.stroke;
    const gridSize = 30.0;
    for (double x = 0; x <= size.width; x += gridSize) { canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint); }
    for (double y = 0; y <= size.height; y += gridSize) { canvas.drawLine(Offset(0, y), Offset(size.width, y), paint); }
    final accentPaint = Paint()..color = accentRed.withOpacity(0.08)..strokeWidth = 1.5..style = PaintingStyle.stroke;
    for (double x = 0; x <= size.width; x += gridSize * 5) { canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint); }
    for (double y = 0; y <= size.height; y += gridSize * 5) { canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint); }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'app_config.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  static const Color bgDark = Color(0xFF0A0E27);
  static const Color accentRed = Color(0xFFF44336);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color softRed = Color(0xFFEF5350);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);

  LinearGradient get redGradient => const LinearGradient(
    colors: [Color(0xFFF44336), Color(0xFFB71C1C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [
              accentRed.withOpacity(0.15),
              bgDark,
              bgDark,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: CustomPaint(
          painter: GridPainter(),
          child: SafeArea(
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                  child: Column(
                    children: [
                      TweenAnimationBuilder(
                        tween: Tween<double>(begin: 0.8, end: 1.0),
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeOutBack,
                        builder: (context, double scale, child) {
                          return Transform.scale(
                            scale: scale,
                            child: Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                gradient: redGradient,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: accentRed.withOpacity(0.5),
                                    blurRadius: 30,
                                    spreadRadius: 5,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.build_circle_outlined,
                                  color: primaryWhite,
                                  size: 42,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 20),
                      ShaderMask(
                        shaderCallback: (bounds) => redGradient.createShader(bounds),
                        child: const Text(
                          "Tools Dashboard",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: glassSecondary,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: primaryWhite.withOpacity(0.08)),
                        ),
                        child: Text(
                          "Advanced Security & OSINT Tools",
                          style: TextStyle(color: softGrey, fontSize: 12, letterSpacing: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: GridView.count(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio: 1.1,
                      children: [
                        buildGlassToolCard(
                          icon: Icons.flash_on_rounded,
                          title: "DDoS Tools",
                          subtitle: "Attack Panel",
                          gradient: redGradient,
                          onTap: () => showDDoSTools(context),
                        ),
                        buildGlassToolCard(
                          icon: Icons.wifi_rounded,
                          title: "Network",
                          subtitle: "WiFi & Spam",
                          gradient: redGradient,
                          onTap: () => showNetworkTools(context),
                        ),
                        buildGlassToolCard(
                          icon: Icons.search_rounded,
                          title: "OSINT",
                          subtitle: "Investigation",
                          gradient: redGradient,
                          onTap: () => showOSINTTools(context),
                        ),
                        buildGlassToolCard(
                          icon: Icons.download_rounded,
                          title: "Downloader",
                          subtitle: "Social Media",
                          gradient: redGradient,
                          onTap: () => showDownloaderTools(context),
                        ),
                        buildGlassToolCard(
                          icon: Icons.build_rounded,
                          title: "Utilities",
                          subtitle: "Extra Tools",
                          gradient: redGradient,
                          onTap: () => showUtilityTools(context),
                        ),
                        buildGlassToolCard(
                          icon: Icons.rocket_launch_rounded,
                          title: "Quick Access",
                          subtitle: "Favorites",
                          gradient: redGradient,
                          onTap: () => showQuickAccess(context),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildGlassToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required LinearGradient gradient,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
      builder: (context, double scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: glassPrimary,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: primaryWhite.withOpacity(0.08)),
            boxShadow: [
              BoxShadow(
                color: accentRed.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: gradient,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: accentRed.withOpacity(0.4),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                  child: Icon(icon, color: primaryWhite, size: 30),
                ),
                const SizedBox(height: 14),
                Text(
                  title,
                  style: const TextStyle(
                    color: primaryWhite,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(color: softGrey, fontSize: 11, letterSpacing: 0.3),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void showGlassBottomSheet(BuildContext context, String title, IconData icon, List<Widget> children) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          color: bgDark,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          border: Border.all(color: primaryWhite.withOpacity(0.08)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: glassPrimary,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(28),
                  topRight: Radius.circular(28),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: redGradient,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: accentRed.withOpacity(0.3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Icon(icon, color: primaryWhite, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    title,
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    children: children,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void showDDoSTools(BuildContext context) {
    showGlassBottomSheet(
      context,
      "DDoS Tools",
      Icons.flash_on_rounded,
      [
        buildGlassToolOption(
          icon: Icons.flash_on_rounded,
          label: "Attack Panel",
          description: "Launch DDoS attacks with power",
          color: accentRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AttackPanel(
                  sessionKey: sessionKey,
                  listDoos: listDoos,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.dns_rounded,
          label: "Manage Server",
          description: "Configure server settings",
          color: softRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ManageServerPage(keyToken: sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void showNetworkTools(BuildContext context) {
    List<Widget> options = [
      buildGlassToolOption(
        icon: Icons.message_rounded,
        label: "Spam NGL",
        description: "Anonymous message spam",
        color: accentRed,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const NglPage()),
          );
        },
      ),
      const SizedBox(height: 12),
      buildGlassToolOption(
        icon: Icons.wifi_off_rounded,
        label: "WiFi Killer (Internal)",
        description: "Internal network attacks",
        color: softRed,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const WifiKillerPage()),
          );
        },
      ),
    ];

    if (userRole == "vip" || userRole == "owner") {
      options.addAll([
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.router_rounded,
          label: "WiFi Killer (External)",
          description: "External network attacks",
          color: darkRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => WifiInternalPage(sessionKey: sessionKey),
              ),
            );
          },
        ),
      ]);
    }

    showGlassBottomSheet(context, "Network Tools", Icons.wifi_rounded, options);
  }

  void showOSINTTools(BuildContext context) {
    showGlassBottomSheet(
      context,
      "OSINT Tools",
      Icons.search_rounded,
      [
        buildGlassToolOption(
          icon: Icons.badge_rounded,
          label: "NIK Detail",
          description: "Indonesian ID card lookup",
          color: accentRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const NikCheckerPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.domain_rounded,
          label: "Domain OSINT",
          description: "Domain information gathering",
          color: softRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DomainOsintPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.person_search_rounded,
          label: "Phone Lookup",
          description: "Phone number investigation",
          color: darkRed,
          onTap: () => showComingSoon(context),
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.email_rounded,
          label: "Email OSINT",
          description: "Email address lookup",
          color: accentRed,
          onTap: () => showComingSoon(context),
        ),
      ],
    );
  }

  void showDownloaderTools(BuildContext context) {
    showGlassBottomSheet(
      context,
      "Media Downloader",
      Icons.download_rounded,
      [
        buildGlassToolOption(
          icon: Icons.video_library_rounded,
          label: "TikTok Downloader",
          description: "Download TikTok videos without watermark",
          color: accentRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const TiktokDownloaderPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.camera_alt_rounded,
          label: "Instagram Downloader",
          description: "Download Instagram content",
          color: softRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const InstagramDownloaderPage()),
            );
          },
        ),
      ],
    );
  }

  void showUtilityTools(BuildContext context) {
    showGlassBottomSheet(
      context,
      "Utility Tools",
      Icons.build_rounded,
      [
        buildGlassToolOption(
          icon: Icons.qr_code_rounded,
          label: "QR Generator",
          description: "Generate QR codes instantly",
          color: accentRed,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const QrGeneratorPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.security_rounded,
          label: "IP Scanner",
          description: "Scan IP addresses",
          color: softRed,
          onTap: () => showComingSoon(context),
        ),
        const SizedBox(height: 12),
        buildGlassToolOption(
          icon: Icons.network_check_rounded,
          label: "Port Scanner",
          description: "Scan open ports",
          color: darkRed,
          onTap: () => showComingSoon(context),
        ),
      ],
    );
  }

  void showQuickAccess(BuildContext context) {
    showComingSoon(context);
  }

  Widget buildGlassToolOption({
    required IconData icon,
    required String label,
    required String description,
    required Color color,
    required VoidCallback onTap,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      child: Container(
        decoration: BoxDecoration(
          color: glassSecondary,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.2), width: 1),
        ),
        child: ListTile(
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, color.withOpacity(0.7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: primaryWhite, size: 20),
          ),
          title: Text(
            label,
            style: const TextStyle(
              color: primaryWhite,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          subtitle: Text(
            description,
            style: TextStyle(
              color: softGrey,
              fontSize: 12,
            ),
          ),
          trailing: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14),
          ),
          onTap: onTap,
        ),
      ),
    );
  }

  void showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                gradient: redGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.hourglass_top_rounded, color: primaryWhite, size: 16),
            ),
            const SizedBox(width: 10),
            const Text(
              'Coming Soon!',
              style: TextStyle(
                color: primaryWhite,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        backgroundColor: glassPrimary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: primaryWhite.withOpacity(0.08)),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

class GridPainter extends CustomPainter {
  static const Color accentRed = Color(0xFFF44336);
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.8
      ..style = PaintingStyle.stroke;
    
    const gridSize = 30.0;
    
    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    
    final accentPaint = Paint()
      ..color = accentRed.withOpacity(0.08)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    
    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), accentPaint);
    }
    
    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), accentPaint);
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
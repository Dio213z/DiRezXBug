import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'splash.dart';
import 'app_config.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool obscurePassword = true;
  String? androidId;
  
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  
  String _countdownTime = "12:53:02";

  late AnimationController animationController;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;
  late Animation<double> scaleAnimation;

  static const Color bgDark = Color(0xFF0B0B0E);
  static const Color glassPrimary = Color(0x1AFFFFFF);
  static const Color glassSecondary = Color(0x0DFFFFFF);
  static const Color accentRed = Color(0xFFF44336);
  static const Color darkRed = Color(0xFFB71C1C);
  static const Color softRed = Color(0xFFEF5350);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFFA0A0A0);

  @override
  void initState() {
    super.initState();
    initAnimations();
    initLogin();
    initVideo();
    _startCountdown();
  }

  void initAnimations() {
    animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    
    fadeAnimation = CurvedAnimation(parent: animationController, curve: Curves.easeOut);
    slideAnimation = Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
      CurvedAnimation(parent: animationController, curve: Curves.easeOutCubic),
    );
    scaleAnimation = Tween<double>(begin: 0.9, end: 1.0).animate(
      CurvedAnimation(parent: animationController, curve: Curves.easeOutBack),
    );
  }

  void _startCountdown() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _countdownTime = _getCurrentTime();
        });
        _startCountdown();
      }
    });
  }

  String _getCurrentTime() {
    final now = DateTime.now();
    return "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
  }

  void initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/login_preview.mp4');
    _videoController.initialize().then((_) {
      if (mounted) {
        setState(() {
          _videoInitialized = true;
        });
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      }
    }).catchError((error) {
      debugPrint("Video error: $error");
      if (mounted) {
        setState(() {
          _videoInitialized = false;
        });
      }
    });
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$kBaseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );

      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (mounted) {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => SplashScreen(
                  username: savedUser,
                  password: savedPass,
                  role: data['role'],
                  sessionKey: data['key'],
                  expiredDate: data['expiredDate'],
                  listBug: (data['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                  listDoos: (data['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                  news: (data['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                ),
              ),
            );
          }
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$kBaseUrl/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        showGlassDialog(
          title: "Access Expired",
          message: "Your access has expired. Please renew your subscription.",
          icon: Icons.timer_outlined,
          color: Colors.orange,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();

        if (errorMsg.contains("perangkat") || errorMsg.contains("device") || errorMsg.contains("another")) {
          showGlassDialog(
            title: "Active Session",
            message: "This account is logged in on another device.\nPlease logout first.",
            icon: Icons.devices,
            color: Colors.orangeAccent,
          );
        } else {
          showGlassDialog(
            title: "Login Failed",
            message: "Invalid username or password.",
            icon: Icons.error_outline,
            color: accentRed,
          );
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => SplashScreen(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                listBug: (validData['listBug'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                listDoos: (validData['listDDoS'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
                news: (validData['news'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
              ),
            ),
          );
        }
      }
    } catch (e) {
      showGlassDialog(
        title: "Connection Error",
        message: "Failed to connect to server.\nPlease check your internet connection.",
        icon: Icons.wifi_off_outlined,
        color: Colors.red,
      );
    }

    setState(() => isLoading = false);
  }

  void showGlassDialog({
    required String title,
    required String message,
    required IconData icon,
    Color color = Colors.redAccent,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: glassPrimary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: primaryWhite.withOpacity(0.1), width: 1.5),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 18),
              ),
            ),
          ],
        ),
        content: Text(message, style: TextStyle(color: softGrey, fontSize: 14, height: 1.4)),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                await launchUrl(
                  Uri.parse("https://t.me/DiRezStore213z"),
                  mode: LaunchMode.externalApplication,
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [accentRed, darkRed]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  "Contact Admin",
                  style: TextStyle(color: primaryWhite, fontWeight: FontWeight.w600, fontSize: 12),
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close", style: TextStyle(color: softGrey, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    animationController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [accentRed.withOpacity(0.15), bgDark, bgDark],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: fadeAnimation,
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 30),
                    SlideTransition(
                      position: slideAnimation,
                      child: ScaleTransition(
                        scale: scaleAnimation,
                        child: Column(
                          children: [
                            ShaderMask(
                              shaderCallback: (bounds) => LinearGradient(
                                colors: [accentRed, softRed, darkRed],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ).createShader(bounds),
                              child: const Text(
                                "DirzZX CORE",
                                style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: primaryWhite, letterSpacing: 1.5),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Premium · Secure · Fast",
                              style: TextStyle(color: softGrey, fontSize: 12, letterSpacing: 0.5, fontWeight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    SlideTransition(
                      position: slideAnimation,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: glassSecondary,
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: accentRed.withOpacity(0.3)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: Colors.red,
                                shape: BoxShape.circle,
                                boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.5), blurRadius: 4)],
                              ),
                            ),
                            const SizedBox(width: 6),
                            const Text("LIVE", style: TextStyle(color: Colors.red, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
                            const SizedBox(width: 12),
                            Container(width: 1, height: 14, color: softGrey.withOpacity(0.3)),
                            const SizedBox(width: 12),
                            Text(
                              _countdownTime,
                              style: TextStyle(color: primaryWhite, fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'monospace'),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    SlideTransition(
                      position: slideAnimation,
                      child: Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: accentRed.withOpacity(0.3), width: 1.5),
                          boxShadow: [BoxShadow(color: accentRed.withOpacity(0.2), blurRadius: 20)],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(19),
                          child: _videoInitialized
                              ? AspectRatio(
                                  aspectRatio: _videoController.value.aspectRatio,
                                  child: VideoPlayer(_videoController),
                                )
                              : Container(
                                  height: 200,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(colors: [accentRed.withOpacity(0.2), darkRed.withOpacity(0.1)]),
                                  ),
                                  child: Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.play_circle_outline, color: accentRed, size: 48),
                                        const SizedBox(height: 8),
                                        Text("PREVIEW", style: TextStyle(color: accentRed, fontSize: 16, fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                                  ),
                                ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    SlideTransition(
                      position: slideAnimation,
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: glassPrimary,
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(color: primaryWhite.withOpacity(0.08)),
                        ),
                        child: Form(
                          key: formKey,
                          child: Column(
                            children: [
                              buildGlassInput(userController, "Username", Icons.person_outline),
                              const SizedBox(height: 16),
                              buildGlassInput(passController, "Password", Icons.lock_outline, isPassword: true),
                              const SizedBox(height: 24),
                              buildGlassButton(),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    SlideTransition(
                      position: slideAnimation,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildFeatureBadge(Icons.shield_outlined, "100% AMAN"),
                          const SizedBox(width: 12),
                          _buildFeatureBadge(Icons.speed, "Ultra CEPAT"),
                          const SizedBox(width: 12),
                          _buildFeatureBadge(Icons.star, "5.0 RATING"),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    SlideTransition(
                      position: slideAnimation,
                      child: Text(
                        "© 2026 DirzZX CORE · All Rights Reserved",
                        style: TextStyle(color: softGrey.withOpacity(0.5), fontSize: 9, letterSpacing: 0.5),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeatureBadge(IconData icon, String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: glassSecondary,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentRed.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(icon, color: accentRed, size: 14),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: softGrey, fontSize: 10, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget buildGlassInput(TextEditingController controller, String label, IconData icon, {bool isPassword = false}) {
    return StatefulBuilder(
      builder: (context, setStateLocal) {
        return Container(
          decoration: BoxDecoration(
            color: glassSecondary,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: primaryWhite.withOpacity(0.05)),
          ),
          child: TextFormField(
            controller: controller,
            obscureText: isPassword && obscurePassword,
            style: const TextStyle(color: primaryWhite, fontSize: 14),
            validator: (value) {
              if (value == null || value.isEmpty) return "Please enter $label";
              return null;
            },
            decoration: InputDecoration(
              labelText: label,
              labelStyle: TextStyle(color: softGrey, fontSize: 12),
              prefixIcon: Icon(icon, color: accentRed, size: 18),
              suffixIcon: isPassword
                  ? IconButton(
                      icon: Icon(obscurePassword ? Icons.visibility_off : Icons.visibility, color: softGrey, size: 16),
                      onPressed: () => setStateLocal(() => obscurePassword = !obscurePassword),
                    )
                  : null,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: primaryWhite.withOpacity(0.05)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: accentRed.withOpacity(0.5), width: 1.5),
              ),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            ),
          ),
        );
      },
    );
  }

  Widget buildGlassButton() {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
        ),
        onPressed: isLoading ? null : login,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [accentRed, darkRed]),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: accentRed.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 5))],
          ),
          child: Center(
            child: isLoading
                ? const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation<Color>(primaryWhite)),
                  )
                : const Text(
                    "MASUK ADA DiRez GANTENG",
                    style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: primaryWhite, letterSpacing: 1.5),
                  ),
          ),
        ),
      ),
    );
  }
}